//MOHIMINUL ISLAM MAHI (22-48725-3)
//ANANNYA TITHI - (22-48992-3)
//ESRATUL JANNAT JUI(22-49013-3)
//ALAMIN(22-47731-2)

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <cmath>
#include <windows.h>
#include <mmsystem.h>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <GL/glut.h>



//D,space ->> Move train
//MOUSE RIGHT KEY - MORNING AND NIGHT
//1 -> Scene1
//2 -> Scene2
//3 -> Scene3


void display();
void reshape(int, int);
void trainTimer(int);
void handleKeyPress(unsigned char, int, int);
void mouseClickHandler(int , int , int , int y);
void drawCircle(float, float, float);
void drawCircle2(float, float, float);
void drawCircle3(float, float, float);
void drawCircle4(float, float, float);
void drawSun(float , float , float , int );

int state = 0;
int spaceState = 0;
extern int environmentState = 0;
int sceneNo = 1;

float cC;
float cP;
float RaDius;
float Cc;
float Cp;
int num_segments;

int button;
int state1;
int o;
int p;
int trainXposition = -2500;
int trainSpeed = 7;



int trafficSoundState = 0;
int rivercolorred =  135;
        int    rivercolorgreen = 206;
        int    rivercolorblue = 250;

        int  rivercolorred1 =  0;
        int  rivercolorgreen1 = 100;
        int rivercolorblue1 = 200;


int car1Xposition = 1100;
int carSpeed = 4;



int car2Xposition = 2200;
int car3Xposition = -2300;
int car4Xposition = -1600;



int truckXPosition = -500;

int truck2Xposition = 0;


int sideWalkColorRed = 0.8;
int sideWalkColorGreen = 0.8;
int sideWalkColorBlue = 0.8;




float boatXPosition = -960.0f; // Start off-screen on the left
float boatXSpeed = 2.0f;


// Boat positions and speeds
float boatX1 = -960.0f, boatSpeed1 = 2.0f;
float boatX2 = -700.0f, boatSpeed2 = 1.8f;
float boatX3 = -400.0f, boatSpeed3 = 2.5f;







float cloud1Position = -50;
float cloud2Position = -350;
float cloud3Position = -750;
float cloud4Position = 1000;
float cloud5Position = 500;
float cloud6Position = 200;


float cloudSpeed = 0.2;
//Change Background Color

//boatX animation funtion
void update(int value) {
 boatXPosition += boatXSpeed; // Move the boat

    // Reverse direction if the boat reaches the screen edges
    if (boatXPosition > 960.0f || boatXPosition < -960.0f) {
        boatXSpeed = -boatXSpeed; // Reverse direction
    }

    glutPostRedisplay();              // Redraw the scene
    glutTimerFunc(20, update, 0);     // Re-register the update function
}


//Boat2 Animation Function
GLfloat position1 = 0.0f;
GLfloat speed1 = 10.0f;
void boat2_update(int value) {
    if (position1 <= -2400) {
        position1 = 0;
    }
    position1 -= speed1;

    glutPostRedisplay();

    glutTimerFunc(70, boat2_update, 0);
}

//Wave Animation Function
GLfloat position2 = 0.0f;
GLfloat speed2 = 10.0f;

void wave2_update(int value) {
    if (position2 >= -960) {
        position2 = -1562;
    }
    position2 += speed2;

    glutPostRedisplay();

    glutTimerFunc(70, wave2_update, 0);
}


GLfloat position3 = 0.0f;
GLfloat speed3 = 10.0f;

void boat1_update(int value) {
    if (position3 >= 1363) {
        position3 = -400;
    }
    position3 += speed3;

    glutPostRedisplay();

    glutTimerFunc(70, boat1_update, 0);
}


void init() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    gluOrtho2D(-960, 960, -540, 540);  // Orthographic projection
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB);
    glutInitWindowPosition(0, 0);
    glutInitWindowSize(1920, 1080);
    glutCreateWindow("City Life in Metro");
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(1000, trainTimer, 0);
    glutKeyboardFunc(handleKeyPress);
   glutMouseFunc(mouseClickHandler);  // Register mouse input




    PlaySound(TEXT("D:\\7th Sem\\Computer Graphics\\CG Codes\\CG Final Project 2025\\Metro.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);




    glutTimerFunc(40, boat2_update, 0);
    glutTimerFunc(70, wave2_update, 0);
    glutTimerFunc(70, boat1_update, 0);
    init();

    glutMainLoop();


}

int cloudColorRed = 255;
int cloudColorGreen = 255;
int cloudColorBlue = 255;

int BuildingWhiteColorRed = 255;
int BuildingWhiteColorGreen = 255;
int BuildingWhiteColorBlue = 255;

int BuildingBlueGlassColorRed = 67;
int BuildingBlueGlassColorGreen = 187;
int BuildingBlueGlassColorBlue = 240;


int mainBuildingColorRed = 235;
int mainBuildingColorGreen = 171;
int mainBuildingColorBlue = 122;


int mainBuildingWindowColorRed = 189;
int mainBuildingWindowColorGreen = 138;
int mainBuildingWindowColorBlue = 97;


int BackgroundBuilding1ColorRed = 127;
int BackgroundBuilding1ColorGreen = 178;
int BackgroundBuilding1ColorBlue = 229;

int BackgroundBuilding2ColorRed = 127;
int BackgroundBuilding2ColorGreen = 204;
int BackgroundBuilding2ColorBlue = 204;

int grassColorRed = 159;
int grassColorGreen = 217;
int grassColorBlue = 0;

int BuildingWhiteColorRed5 = 25;
int BuildingWhiteColorGreen5 = 94;
int BuildingWhiteColorBlue5 = 94;

int BuildingWhiteColorRed1 = 230;
int BuildingWhiteColorGreen1 = 230;
int BuildingWhiteColorBlue1 = 250;

int BuildingWhiteColorRed2 = 255;
int BuildingWhiteColorGreen2 = 203;
int BuildingWhiteColorBlue2 = 199;

int BuildingWhiteColorRed3 = 246;
int BuildingWhiteColorGreen3 = 209;
int BuildingWhiteColorBlue3 = 119;

int BuildingWhiteColorRed4 = 101;
int BuildingWhiteColorGreen4 = 156;
int BuildingWhiteColorBlue4 = 211;

int BuildingBlueGlassColorRed1 = 115;
int BuildingBlueGlassColorGreen1 = 79;
int BuildingBlueGlassColorBlue1 = 150;

int BuildingBlueGlassColorRed2 = 128;
int BuildingBlueGlassColorGreen2 = 0;
int BuildingBlueGlassColorBlue2 = 0;

int BuildingBlueGlassColorRed3 = 167;
int BuildingBlueGlassColorGreen3 = 88;
int BuildingBlueGlassColorBlue3 = 103;

int BuildingBlueGlassColorRed4 = 40;
int BuildingBlueGlassColorGreen4 = 57;
int BuildingBlueGlassColorBlue4 = 129;

int trainBaseColorRed = 255;
int trainBaseColorGreen = 255;
int trainBaseColorBlue = 255;

int trainBaseColor2Red = 255;
int trainBaseColor2Green = 255;
int trainBaseColor2Blue = 255;

int trainWindowColorRed = 90;
int trainWindowColorGreen = 90;
int trainWindowColorBlue = 90;

int trainBaseGreenColorRed = 0;
int trainBaseGreenColorGreen = 174;
int trainBaseGreenColorBlue = 86;

int car1YellowColorRed = 254;
int car1YellowColorGreen = 185;
int car1YellowColorBlue = 1;

int car1BlackColorRed = 72;
int car1BlackColorGreen = 72;
int car1BlackColorBlue = 72;

int car2GreenColorRed = 34;
int car2GreenColorGreen = 139;
int car2GreenColorBlue = 34;

int car4WhiteColorRed = 255;
int car4WhiteColorGreen = 255;
int car4WhiteColorBlue = 255;

int truck1RedcolorRed = 221;
int truck1RedcolorGreen = 67;
int truck1RedcolorBlue = 55;

int truck2BluecolorRed = 1;
int truck2BluecolorGreen = 142;
int truck2BluecolorBlue = 230;

int trainStationLightColorRed = 193;
int trainStationLightColorGreen = 196;
int trainStationLightColorBlue = 196;

int treeFoliageColorRed = 240;
int treeFoliageColorGreen = 228;
int treeFoliageColorBlue = 130;

int lampPostLightColorRed = 150;
int lampPostLightColorGreen = 150;
int lampPostLightColorBlue = 150;

float lastTime = 0.0f; // Time of the last update
int currentLight = 0;  // 0 = Red, 1 = Yellow, 2 = Green
float redLightDuration = 10.0f;   // Red light stays for 3 seconds
float yellowLightDuration = 3.0f; // Yellow light stays for 1 second
float greenLightDuration = 20.0f;  // Green light stays for 2 seconds

float timerInterval = 0.0f;  // The current light's duration (will change dynamically)
float lastChangeTime = 0.0f; // Time when the light was last changed

float x = -40.0f + 30.0f + 30.0f, radius = 8.0f; // Position and radius for the lights
int triangleAmount = 50;
float twicePi = 2.0f * M_PI;


//All of Drawing is in this Display Function

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();



    //Gradient Sky


    //Day
    if (sceneNo == 1) {
        if (environmentState == 0) {


            int SkyRed = 131;   //DAY SKY
            int SkyGreen = 231;
            int SkyBlue = 246;
            glBegin(GL_QUADS);
            glColor3ub(SkyRed, SkyGreen, SkyBlue); //TOP gradient
            glVertex2f(960, 540);
            glVertex2f(-960, 540);
            glColor3ub(SkyRed + 124, SkyGreen + 24, SkyBlue + 9);//Bottom Gradient
            glVertex2f(-960, -0);
            glVertex2f(960, -0);
            glEnd();



            BuildingWhiteColorRed = 255;
            BuildingWhiteColorGreen = 255;
            BuildingWhiteColorBlue = 255;

            BuildingWhiteColorRed5 = 25;
            BuildingWhiteColorGreen5 = 94;
            BuildingWhiteColorBlue5 = 94;

           BuildingWhiteColorRed1 = 230;
           BuildingWhiteColorGreen1 = 230;
           BuildingWhiteColorBlue1 = 250;

           BuildingWhiteColorRed2 = 255;
           BuildingWhiteColorGreen2 = 203;
           BuildingWhiteColorBlue2 = 199;

           BuildingWhiteColorRed3 = 246;
           BuildingWhiteColorGreen3 = 209;
           BuildingWhiteColorBlue3 = 119;

           BuildingWhiteColorRed4 = 101;
           BuildingWhiteColorGreen4 = 156;
           BuildingWhiteColorBlue4 = 211;

            BuildingBlueGlassColorRed = 210;
            BuildingBlueGlassColorGreen = 140;
            BuildingBlueGlassColorBlue = 100;

           BuildingBlueGlassColorRed1 = 115;
           BuildingBlueGlassColorGreen1 = 79;
           BuildingBlueGlassColorBlue1 = 150;

           BuildingBlueGlassColorRed2 = 128;
           BuildingBlueGlassColorGreen2 = 0;
           BuildingBlueGlassColorBlue2 = 0;

           BuildingBlueGlassColorRed3 = 167;
           BuildingBlueGlassColorGreen3 = 88;
           BuildingBlueGlassColorBlue3 = 103;

           BuildingBlueGlassColorRed4 = 40;
           BuildingBlueGlassColorGreen4 = 57;
           BuildingBlueGlassColorBlue4 = 129;





            BackgroundBuilding1ColorRed = 75;
            BackgroundBuilding1ColorGreen = 105;
            BackgroundBuilding1ColorBlue = 135;


            BackgroundBuilding2ColorRed = 134;
            BackgroundBuilding2ColorGreen = 116;
            BackgroundBuilding2ColorBlue = 65;

            mainBuildingColorRed = 22;
            mainBuildingColorGreen = 109;
            mainBuildingColorBlue = 122;


            mainBuildingWindowColorRed = 91;
            mainBuildingWindowColorGreen = 182;
            mainBuildingWindowColorBlue = 182;

            grassColorRed = 67;
            grassColorGreen = 177;
            grassColorBlue = 124;

            rivercolorred =  135;
            rivercolorgreen = 206;
            rivercolorblue = 250;

            rivercolorred1 =  0;
            rivercolorgreen1 = 100;
            rivercolorblue1 = 200;

            trainBaseColorRed = 255;
            trainBaseColorGreen = 255;
            trainBaseColorBlue = 255;

            trainBaseColor2Red = 215;
            trainBaseColor2Green = 215;
            trainBaseColor2Blue = 215;

            trainWindowColorRed = 90;
            trainWindowColorGreen = 90;
            trainWindowColorBlue = 90;

            trainBaseGreenColorRed = 0;
            trainBaseGreenColorGreen = 174;
            trainBaseGreenColorBlue = 86;

            trainStationLightColorRed = 193;
            trainStationLightColorGreen = 196;
            trainStationLightColorBlue = 196;

            sideWalkColorRed = 0.8;
            sideWalkColorGreen = 0.8;
            sideWalkColorBlue = 0.8;

           treeFoliageColorRed = 240;
 treeFoliageColorGreen = 228;
 treeFoliageColorBlue = 130;



        }
        else {

            int SkyRed = 1;    //NIGHT SKY
            int SkyGreen = 2;
            int SkyBlue = 40;
            glBegin(GL_QUADS);
            glColor3ub(SkyRed, SkyGreen, SkyBlue); //Top Gradient
            glVertex2f(960, 540);
            glVertex2f(-960, 540);


            glColor3ub(SkyRed + 1, SkyGreen + 84, SkyBlue + 86);//Bottom Gradient
            glVertex2f(-960, 0);
            glVertex2f(960, 0);
            glEnd();

            srand(5);

            for (int i = 1; i <= 500; i++) {
                int Xrandom = -960 + (rand() % 1921);
                int Yrandom = -540 + (rand() % 1081);
                int Radiusrandom = -3 + (rand() % 6);

                drawCircle(Xrandom, Yrandom, Radiusrandom);

            }





            BuildingWhiteColorRed = 50;
            BuildingWhiteColorGreen = 50;
            BuildingWhiteColorBlue = 50;

                 BuildingBlueGlassColorRed = 210;
           BuildingBlueGlassColorGreen = 140;
           BuildingBlueGlassColorBlue1 = 100;


              BuildingBlueGlassColorRed1 = 230;
           BuildingBlueGlassColorGreen1 = 230;
           BuildingBlueGlassColorBlue1 = 250;

           BuildingBlueGlassColorRed2 = 210;
           BuildingBlueGlassColorGreen2 = 140;
           BuildingBlueGlassColorBlue2 = 100;

           BuildingBlueGlassColorRed3 = 210;
           BuildingBlueGlassColorGreen3 = 140;
           BuildingBlueGlassColorBlue3 = 100;

           BuildingBlueGlassColorRed4 = 210;
           BuildingBlueGlassColorGreen4 = 140;
           BuildingBlueGlassColorBlue4 = 100;



            BackgroundBuilding1ColorRed = 170;
            BackgroundBuilding1ColorGreen = 110;
            BackgroundBuilding1ColorBlue = 80;


            BackgroundBuilding2ColorRed = 130;
            BackgroundBuilding2ColorGreen = 100;
            BackgroundBuilding2ColorBlue = 70;

            mainBuildingColorRed = 50;
            mainBuildingColorGreen = 50;
            mainBuildingColorBlue = 50;


            mainBuildingWindowColorRed = 240;
            mainBuildingWindowColorGreen = 228;
            mainBuildingWindowColorBlue = 130;

             grassColorRed = 11;
            grassColorGreen = 61;
            grassColorBlue = 22;


            rivercolorred =  22;
            rivercolorgreen = 64;
            rivercolorblue = 194;

            rivercolorred1 = 11;
            rivercolorgreen1 = 34;
            rivercolorblue1 = 106;



            trainBaseColorRed = 75;
            trainBaseColorGreen = 75;
            trainBaseColorBlue = 75;

            trainBaseColor2Red = 45;
            trainBaseColor2Green = 45;
            trainBaseColor2Blue = 45;

            trainWindowColorRed = 255;
            trainWindowColorGreen = 249;
            trainWindowColorBlue = 196;


            trainBaseGreenColorRed = 17;
            trainBaseGreenColorGreen = 81;
            trainBaseGreenColorBlue = 49;

            trainStationLightColorRed = 255;
            trainStationLightColorGreen = 196;
            trainStationLightColorBlue = 14;



            cloudColorRed = 3;
            cloudColorGreen = 104;
            cloudColorBlue = 192;

            truck1RedcolorRed = 143;
            truck1RedcolorGreen = 36;
            truck1RedcolorBlue = 28;


            truck2BluecolorRed = 0;
            truck2BluecolorGreen = 92;
            truck2BluecolorBlue = 149;



            sideWalkColorRed = 0.6;
            sideWalkColorGreen = 0.6;
            sideWalkColorBlue = 0.6;





        }
         //grass

        //Cloud

        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud1Position, 400);
        glVertex2f(cloud1Position - 200, 400);
        glVertex2f(cloud1Position - 200, 350);
        glVertex2f(cloud1Position, 350);
        glEnd();

        drawCircle4(cloud1Position - 200, 400, 50);
        drawCircle4(cloud1Position, 410, 60);
        drawCircle4(cloud1Position - 100, 430, 80);



        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud2Position, 270);
        glVertex2f(cloud2Position - 150, 270);
        glVertex2f(cloud2Position - 150, 220);
        glVertex2f(cloud2Position, 220);
        glEnd();

        drawCircle4(cloud2Position - 150, 270, 50);
        drawCircle4(cloud2Position, 260, 40);
        drawCircle4(cloud2Position - 80, 280, 60);


        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud3Position, 380);
        glVertex2f(cloud3Position - 150, 380);
        glVertex2f(cloud3Position - 150, 330);
        glVertex2f(cloud3Position, 330);
        glEnd();

        drawCircle4(cloud3Position - 150, 380, 50);
        drawCircle4(cloud3Position, 390, 60);
        drawCircle4(cloud3Position - 80, 390, 60);






        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud4Position, 320);
        glVertex2f(cloud4Position - 200, 320);
        glVertex2f(cloud4Position - 200, 270);
        glVertex2f(cloud4Position, 270);
        glEnd();

        drawCircle4(cloud4Position - 200, 320, 50);
        drawCircle4(cloud4Position, 330, 60);
        drawCircle4(cloud4Position - 100, 350, 80);



        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud5Position, 400);
        glVertex2f(cloud5Position - 150, 400);
        glVertex2f(cloud5Position - 150, 350);
        glVertex2f(cloud5Position, 350);
        glEnd();

        drawCircle4(cloud5Position - 150, 400, 50);
        drawCircle4(cloud5Position, 400, 50);
        drawCircle4(cloud5Position - 80, 420, 70);


        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud6Position, 290);
        glVertex2f(cloud6Position - 150, 290);
        glVertex2f(cloud6Position - 150, 240);
        glVertex2f(cloud6Position, 240);
        glEnd();

        drawCircle4(cloud6Position - 150, 290, 50);
        drawCircle4(cloud6Position, 300, 60);
        drawCircle4(cloud6Position - 80, 300, 60);


        //Cloud-End







        //    Gradient Sky ->End


        //Green Ground
        glBegin(GL_QUADS);
// Top Vertex - Lighter Green
glColor3ub(grassColorRed, grassColorGreen, grassColorBlue);  // Light green
glTexCoord2f(0.0f, 1.0f); glVertex2f(-960, -20);
glTexCoord2f(1.0f, 1.0f); glVertex2f(960, -20);

// Bottom Vertex - Darker Green
glColor3ub(grassColorRed, grassColorGreen, grassColorBlue);  // Dark green
glTexCoord2f(1.0f, 0.0f); glVertex2f(960, -440);
glTexCoord2f(0.0f, 0.0f); glVertex2f(-960, -440);

glEnd();

//flower garden
// Sunflower garden with realistic curved petals and big leaves

float flowerPositions[][2] = {
    {-900, -200}, {-800, -120}, {-700, -140}, {-600, -160}, {-500, -180},
    {-400, -100},{-420, -190},
    {-900,-70},{-800, -220},{-600, -75}, {-580, -240}, {-500, -75}


};

for (int i = 0; i < 12; i++) {
    float x = flowerPositions[i][0];
    float y = flowerPositions[i][1];

    // Draw sunflower petals (curved shape)
    glColor3f(1.0, 0.8, 0.0); // Yellow petals
    for (int j = 0; j < 360; j += 20) {
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        glVertex2f(x + 25 * cos(j * 3.1416 / 180), y + 25 * sin(j * 3.1416 / 180));
        glVertex2f(x + 25 * cos((j + 20) * 3.1416 / 180), y + 25 * sin((j + 20) * 3.1416 / 180));
        glEnd();
    }

    // Draw center of flower
    glColor3f(0.5, 0.25, 0.0); // Brown center
    glBegin(GL_POLYGON);
    for (int k = 0; k < 360; k += 10) {
        glVertex2f(x + 10 * cos(k * 3.1416 / 180), y + 10 * sin(k * 3.1416 / 180));
    }
    glEnd();

    // Draw sunflower stem
    glColor3f(0.0, 0.5, 0.0); // Green stem
    glBegin(GL_QUADS);
    glVertex2f(x - 3, y - 10);
    glVertex2f(x + 3, y - 10);
    glVertex2f(x + 3, y - 50);
    glVertex2f(x - 3, y - 50);
    glEnd();

    // Draw big leaves
    glColor3f(0.0, 0.6, 0.0); // Green leaves
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y - 30);
    glVertex2f(x - 20, y - 50);
    glVertex2f(x - 25, y - 40);
    glVertex2f(x - 20, y - 25);
    glEnd();

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y - 30);
    glVertex2f(x + 20, y - 50);
    glVertex2f(x + 25, y - 40);
    glVertex2f(x + 20, y - 25);
    glEnd();
}


// Red flower positions
float redFlowerPositions[][2] = {
    {880, -250}, {760, -250}, {810, -70}, {700, -160}, {450, -180},
    {350, -100}, {250, -120}, {770, -130}, {840, -160},{870,-80},{530, -120}, {450, -80},
    {350, -190}, {500, -240}
};

for (int i = 0; i < 14; i++) {
    float x = redFlowerPositions[i][0];
    float y = redFlowerPositions[i][1];

    // Draw red flower petals (curved shape)
    glColor3f(1.0, 0.0, 0.0); // Red petals
    for (int j = 0; j < 360; j += 20) {
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        glVertex2f(x + 20 * cos(j * 3.1416 / 180), y + 20 * sin(j * 3.1416 / 180));
        glVertex2f(x + 20 * cos((j + 20) * 3.1416 / 180), y + 20 * sin((j + 20) * 3.1416 / 180));
        glEnd();
    }

    // Draw center of flower
    glColor3f(0.5, 0.25, 0.0); // Brown center
    glBegin(GL_POLYGON);
    for (int k = 0; k < 360; k += 10) {
        glVertex2f(x + 8 * cos(k * 3.1416 / 180), y + 8 * sin(k * 3.1416 / 180));
    }
    glEnd();

    // Draw flower stem
    glColor3f(0.0, 0.5, 0.0); // Green stem
    glBegin(GL_QUADS);
    glVertex2f(x - 2, y - 10);
    glVertex2f(x + 2, y - 10);
    glVertex2f(x + 2, y - 40);
    glVertex2f(x - 2, y - 40);
    glEnd();

    // Draw leaves
    glColor3f(0.0, 0.6, 0.0); // Green leaves
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y - 20);
    glVertex2f(x - 15, y - 40);
    glVertex2f(x - 20, y - 30);
    glVertex2f(x - 15, y - 15);
    glEnd();

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y - 20);
    glVertex2f(x + 15, y - 40);
    glVertex2f(x + 20, y - 30);
    glVertex2f(x + 15, y - 15);
    glEnd();
}
// Rose flower positions within x-axis range of -350 to +350
float roseFlowerPositions[][2] = {
      {-120, -100}, {-70, -50}, {-190, -200}, {30, -260}, {80, -190},
    {-140, -50}, {-70, -260}, {-20, -170}, {30, -100}, {80, -100},
    {-160, -180}, {-70, -150}, {-20, -110}, {30, -160}, {80, -150},
    {120, -190},{30,-50}
};

const float DEG2RAD = 3.1416 / 180.0;
float size = 0.5; // Adjust this value to change the size of the flowers

for (int i = 0; i < 17; i++) {
    float x = roseFlowerPositions[i][0];
    float y = roseFlowerPositions[i][1];

    // Draw rose petals (more complex shape)
    glColor3f(0.5, 0.0, 0.5); // purple petals
    for (int j = 0; j < 360; j += 45) {
        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(x, y);
        for (int k = 0; k <= 360; k += 10) {
            float radius = size * (20 + 10 * sin(2 * k * DEG2RAD));
            glVertex2f(x + radius * cos((j + k) * DEG2RAD), y + radius * sin((j + k) * DEG2RAD));
        }
        glEnd();
    }

    // Draw center of flower
    glColor3f(1.0, 1.0, 0.0); // yellow center
    glBegin(GL_POLYGON);
    for (int k = 0; k < 360; k += 10) {
        glVertex2f(x + size * 8 * cos(k * DEG2RAD), y + size * 8 * sin(k * DEG2RAD));
    }
    glEnd();

    // Draw flower stem
    glColor3f(0.0, 0.5, 0.0); // Green stem
    glBegin(GL_QUADS);
    glVertex2f(x - 2 * size, y - 10 * size);
    glVertex2f(x + 2 * size, y - 10 * size);
    glVertex2f(x + 2 * size, y - 40 * size);
    glVertex2f(x - 2 * size, y - 40 * size);
    glEnd();

    // Draw leaves
    glColor3f(0.0, 0.6, 0.0); // Green leaves
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y - 20 * size);
    glVertex2f(x - 15 * size, y - 40 * size);
    glVertex2f(x - 20 * size, y - 30 * size);
    glVertex2f(x - 15 * size, y - 15 * size);
    glEnd();

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y - 20 * size);
    glVertex2f(x + 15 * size, y - 40 * size);
    glVertex2f(x + 20 * size, y - 30 * size);
    glVertex2f(x + 15 * size, y - 15 * size);
    glEnd();
}


//flower garden end








        //Asphalt Road

        glBegin(GL_QUADS);
// Top vertices with sky blue color
glColor3ub(135, 206, 250); // Sky blue
glVertex2f(960, -400);
glVertex2f(-960, -400);

// Bottom vertices with deeper blue color
glColor3ub(0, 100, 200); // Deep blue
glVertex2f(-960, -540);
glVertex2f(960, -540);
glEnd();

        //Road Lines



        //Asphalt Road ->End


        //Sidewalk

        glBegin(GL_QUADS);
        glColor3f(0.5, 0.5, 0.5);
        glVertex2f(960, -350);
        glVertex2f(-960, -350);
        glVertex2f(-960, -358);
        glVertex2f(960, -358);
        glEnd();


        glBegin(GL_QUADS);
        glColor3f(0.8, 0.8, 0.8);
        glVertex2f(960, -300);
        glVertex2f(-960, -300);
        glVertex2f(-960, -340);
        glVertex2f(960, -340);
        glEnd();


        //SideWalk -> Emd



        //Train Station
        glBegin(GL_QUADS);
        glColor3ub(146, 145, 144);
        glVertex2f(600, 225);
        glVertex2f(-600, 225);
        glVertex2f(-600, 200);
        glVertex2f(600, 200);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(78, 78, 76);
        glVertex2f(600, 200);
        glVertex2f(-600, 200);
        glVertex2f(-600, 185);
        glVertex2f(600, 185);
        glEnd();







        int trainStationPillarXposition = 500;   //Train Station Pillar

        for (int i = 0; i < 5;i++) {
            if (trainStationPillarXposition > -510) {
                glBegin(GL_QUADS);
                glColor3ub(78, 78, 76);
                glVertex2f(trainStationPillarXposition, 200);
                glVertex2f(trainStationPillarXposition - 20, 200);
                glVertex2f(trainStationPillarXposition - 20, 150);
                glVertex2f(trainStationPillarXposition, 150);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(78, 78, 76);
                glVertex2f(trainStationPillarXposition - 4, 150);
                glVertex2f(trainStationPillarXposition - 16, 150);
                glVertex2f(trainStationPillarXposition - 16, 0);
                glVertex2f(trainStationPillarXposition - 4, 0);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(253, 180, 78);
                glVertex2f(trainStationPillarXposition - 4, 100);
                glVertex2f(trainStationPillarXposition - 16, 100);
                glVertex2f(trainStationPillarXposition - 16, 85);
                glVertex2f(trainStationPillarXposition - 4, 85);
                glEnd();


            }
            trainStationPillarXposition -= 333;
        }

        glBegin(GL_QUADS);
        glColor3ub(204, 189, 172);
        glVertex2f(650, 25);
        glVertex2f(-650, 25);
        glVertex2f(-650, 0);
        glVertex2f(650, 0);
        glEnd();


        int trainStationBenchXPosition = 370; //TrainStationBench

        for (int i = 0;i < 3;i++) {
            if (trainStationBenchXPosition > -600) {
                glBegin(GL_QUADS);
                glColor3ub(62, 72, 123);
                glVertex2f(trainStationBenchXPosition, 70);
                glVertex2f(trainStationBenchXPosition - 30, 70);
                glVertex2f(trainStationBenchXPosition - 30, 40);
                glVertex2f(trainStationBenchXPosition, 40);
                glEnd();


                glBegin(GL_QUADS);
                glColor3ub(62, 72, 123);
                glVertex2f(trainStationBenchXPosition - 35, 70);
                glVertex2f(trainStationBenchXPosition - 65, 70);
                glVertex2f(trainStationBenchXPosition - 65, 40);
                glVertex2f(trainStationBenchXPosition - 35, 40);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(62, 72, 123);
                glVertex2f(trainStationBenchXPosition - 70, 70);
                glVertex2f(trainStationBenchXPosition - 100, 70);
                glVertex2f(trainStationBenchXPosition - 100, 40);
                glVertex2f(trainStationBenchXPosition - 70, 40);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(23, 24, 90);
                glVertex2f(trainStationBenchXPosition + 2, 38);
                glVertex2f(trainStationBenchXPosition - 32, 38);
                glVertex2f(trainStationBenchXPosition - 32, 46);
                glVertex2f(trainStationBenchXPosition + 2, 45);
                glEnd();


                glBegin(GL_QUADS);
                glColor3ub(23, 24, 90);
                glVertex2f(trainStationBenchXPosition - 33, 38);
                glVertex2f(trainStationBenchXPosition - 67, 38);
                glVertex2f(trainStationBenchXPosition - 67, 45);
                glVertex2f(trainStationBenchXPosition - 33, 45);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(23, 24, 90);
                glVertex2f(trainStationBenchXPosition - 68, 38);
                glVertex2f(trainStationBenchXPosition - 102, 38);
                glVertex2f(trainStationBenchXPosition - 102, 45);
                glVertex2f(trainStationBenchXPosition - 68, 45);
                glEnd();


                glBegin(GL_QUADS);
                glColor3ub(210, 210, 210);
                glVertex2f(trainStationBenchXPosition + 5, 38);
                glVertex2f(trainStationBenchXPosition - 105, 38);
                glVertex2f(trainStationBenchXPosition - 105, 35);
                glVertex2f(trainStationBenchXPosition + 5, 35);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(210, 210, 210);
                glVertex2f(trainStationBenchXPosition + 5, 35);
                glVertex2f(trainStationBenchXPosition + 2, 35);
                glVertex2f(trainStationBenchXPosition + 2, 25);
                glVertex2f(trainStationBenchXPosition + 5, 25);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(210, 210, 210);
                glVertex2f(trainStationBenchXPosition - 102, 35);
                glVertex2f(trainStationBenchXPosition - 105, 35);
                glVertex2f(trainStationBenchXPosition - 105, 25);
                glVertex2f(trainStationBenchXPosition - 102, 25);
                glEnd();

            }
            trainStationBenchXPosition -= 325;

        }


        int trainStationLightXPosition = 355;  //Light

        for (int i = 0; i < 3; i++) {
            if (trainStationLightXPosition > -600) {
                glBegin(GL_QUADS);
                glColor3ub(120, 127, 117);
                glVertex2f(trainStationLightXPosition, 160);
                glVertex2f(trainStationLightXPosition - 75, 160);
                glVertex2f(trainStationLightXPosition - 75, 150);
                glVertex2f(trainStationLightXPosition, 150);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(trainStationLightColorRed, trainStationLightColorGreen, trainStationLightColorBlue);
                glVertex2f(trainStationLightXPosition, 150);
                glVertex2f(trainStationLightXPosition - 75, 150);
                glVertex2f(trainStationLightXPosition - 70, 145);
                glVertex2f(trainStationLightXPosition - 5, 145);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(120, 127, 117);
                glVertex2f(trainStationLightXPosition - 10, 185);
                glVertex2f(trainStationLightXPosition - 13, 185);
                glVertex2f(trainStationLightXPosition - 13, 160);
                glVertex2f(trainStationLightXPosition - 10, 160);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(120, 127, 117);
                glVertex2f(trainStationLightXPosition - 65, 185);
                glVertex2f(trainStationLightXPosition - 62, 185);
                glVertex2f(trainStationLightXPosition - 62, 160);
                glVertex2f(trainStationLightXPosition - 65, 160);
                glEnd();

            }
            trainStationLightXPosition -= 325;
        }



        //Train -Begin

        //Body1

        glBegin(GL_POLYGON); //Train Base
        glColor3ub(trainBaseColorRed, trainBaseColorGreen, trainBaseColorBlue);
        glVertex2f(trainXposition + 435, 130);
        glVertex2f(trainXposition, 130);
        glVertex2f(trainXposition - 20, 120);
        glVertex2f(trainXposition - 70, 60);
        glVertex2f(trainXposition - 70, 25);
        glVertex2f(trainXposition - 50, 5);
        glVertex2f(trainXposition, 0);
        glVertex2f(trainXposition + 420, 0);
        glVertex2f(trainXposition + 450, 25);
        glVertex2f(trainXposition + 450, 120);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainBaseColor2Red, trainBaseColor2Green, trainBaseColor2Blue);
        glVertex2f(trainXposition + 450, 120);
        glVertex2f(trainXposition - 20, 120);
        glVertex2f(trainXposition - 70, 60);
        glVertex2f(trainXposition + 450, 60);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(trainBaseGreenColorRed, trainBaseGreenColorGreen, trainBaseGreenColorBlue);
        glVertex2f(trainXposition + 450, 30);
        glVertex2f(trainXposition - 70, 30);
        glVertex2f(trainXposition - 70, 25);
        glVertex2f(trainXposition - 50, 0);
        glVertex2f(trainXposition + 420, 0);
        glVertex2f(trainXposition + 450, 25);
        glEnd();

        //Windows
        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 20, 110);
        glVertex2f(trainXposition - 28, 110);
        glVertex2f(trainXposition - 62, 70);
        glVertex2f(trainXposition + 20, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 110, 110);
        glVertex2f(trainXposition + 30, 110);
        glVertex2f(trainXposition + 30, 70);
        glVertex2f(trainXposition + 110, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 200, 110);
        glVertex2f(trainXposition + 120, 110);
        glVertex2f(trainXposition + 120, 70);
        glVertex2f(trainXposition + 200, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 290, 110);
        glVertex2f(trainXposition + 210, 110);
        glVertex2f(trainXposition + 210, 70);
        glVertex2f(trainXposition + 290, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 440, 110);
        glVertex2f(trainXposition + 360, 110);
        glVertex2f(trainXposition + 360, 70);
        glVertex2f(trainXposition + 440, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 322, 110);
        glVertex2f(trainXposition + 300, 110);
        glVertex2f(trainXposition + 300, 70);
        glVertex2f(trainXposition + 322, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 350, 110);
        glVertex2f(trainXposition + 328, 110);
        glVertex2f(trainXposition + 328, 70);
        glVertex2f(trainXposition + 350, 70);
        glEnd();


        glLineWidth(2.0f);
        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 325.5, 120);
        glVertex2f(trainXposition + 325.5, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 295, 120);
        glVertex2f(trainXposition + 295, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 355, 120);
        glVertex2f(trainXposition + 355, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 355, 120);
        glVertex2f(trainXposition + 295, 120);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 355, 20);
        glVertex2f(trainXposition + 295, 20);
        glEnd();



        //Body2

        glBegin(GL_POLYGON); //Train Base
        glColor3ub(trainBaseColorRed, trainBaseColorGreen, trainBaseColorBlue);
        glVertex2f(trainXposition + 935, 130);
        glVertex2f(trainXposition + 480, 130);
        glVertex2f(trainXposition + 460, 120);
        glVertex2f(trainXposition + 460, 25);
        glVertex2f(trainXposition + 480, 0);
        glVertex2f(trainXposition + 920, 0);
        glVertex2f(trainXposition + 950, 25);
        glVertex2f(trainXposition + 950, 120);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainBaseColor2Red, trainBaseColor2Green, trainBaseColor2Blue);
        glVertex2f(trainXposition + 950, 120);
        glVertex2f(trainXposition + 460, 120);
        glVertex2f(trainXposition + 460, 60);
        glVertex2f(trainXposition + 950, 60);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(trainBaseGreenColorRed, trainBaseGreenColorGreen, trainBaseGreenColorBlue);
        glVertex2f(trainXposition + 950, 30);
        glVertex2f(trainXposition + 460, 30);
        glVertex2f(trainXposition + 460, 25);
        glVertex2f(trainXposition + 480, 0);
        glVertex2f(trainXposition + 920, 0);
        glVertex2f(trainXposition + 950, 25);
        glEnd();



        //Windows

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 550, 110);
        glVertex2f(trainXposition + 470, 110);
        glVertex2f(trainXposition + 470, 70);
        glVertex2f(trainXposition + 550, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 640, 110);
        glVertex2f(trainXposition + 560, 110);
        glVertex2f(trainXposition + 560, 70);
        glVertex2f(trainXposition + 640, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 730, 110);
        glVertex2f(trainXposition + 650, 110);
        glVertex2f(trainXposition + 650, 70);
        glVertex2f(trainXposition + 730, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 820, 110);
        glVertex2f(trainXposition + 740, 110);
        glVertex2f(trainXposition + 740, 70);
        glVertex2f(trainXposition + 820, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 850, 110);
        glVertex2f(trainXposition + 830, 110);
        glVertex2f(trainXposition + 830, 70);
        glVertex2f(trainXposition + 850, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 876, 110);
        glVertex2f(trainXposition + 856, 110);
        glVertex2f(trainXposition + 856, 70);
        glVertex2f(trainXposition + 876, 70);
        glEnd();


        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 853.5, 120);
        glVertex2f(trainXposition + 853.5, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 825, 120);
        glVertex2f(trainXposition + 825, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 881, 120);
        glVertex2f(trainXposition + 881, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 881, 120);
        glVertex2f(trainXposition + 825, 120);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 881, 20);
        glVertex2f(trainXposition + 825, 20);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 940, 110);
        glVertex2f(trainXposition + 886, 110);
        glVertex2f(trainXposition + 886, 70);
        glVertex2f(trainXposition + 940, 70);
        glEnd();



        //Body3

        glBegin(GL_POLYGON); //Train Base
        glColor3ub(trainBaseColorRed, trainBaseColorGreen, trainBaseColorBlue);
        glVertex2f(trainXposition + 1410, 130);
        glVertex2f(trainXposition + 980, 130);
        glVertex2f(trainXposition + 960, 120);

        glVertex2f(trainXposition + 960, 25);
        glVertex2f(trainXposition + 980, 0);
        glVertex2f(trainXposition + 1460, 0);
        glVertex2f(trainXposition + 1480, 25);
        glVertex2f(trainXposition + 1480, 60);
        glVertex2f(trainXposition + 1430, 120);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(trainBaseColor2Red, trainBaseColor2Green, trainBaseColor2Blue);
        glVertex2f(trainXposition + 1430, 120);
        glVertex2f(trainXposition + 960, 120);
        glVertex2f(trainXposition + 960, 60);
        glVertex2f(trainXposition + 1480, 60);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(trainBaseGreenColorRed, trainBaseGreenColorGreen, trainBaseGreenColorBlue);
        glVertex2f(trainXposition + 1480, 30);
        glVertex2f(trainXposition + 960, 30);
        glVertex2f(trainXposition + 960, 25);
        glVertex2f(trainXposition + 980, 0);
        glVertex2f(trainXposition + 1460, 0);
        glVertex2f(trainXposition + 1480, 25);
        glVertex2f(trainXposition + 1480, 30);


        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1050, 110);
        glVertex2f(trainXposition + 970, 110);
        glVertex2f(trainXposition + 970, 70);
        glVertex2f(trainXposition + 1050, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1200, 110);
        glVertex2f(trainXposition + 1120, 110);
        glVertex2f(trainXposition + 1120, 70);
        glVertex2f(trainXposition + 1200, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1290, 110);
        glVertex2f(trainXposition + 1210, 110);
        glVertex2f(trainXposition + 1210, 70);
        glVertex2f(trainXposition + 1290, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1380, 110);
        glVertex2f(trainXposition + 1300, 110);
        glVertex2f(trainXposition + 1300, 70);
        glVertex2f(trainXposition + 1380, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1440, 110);
        glVertex2f(trainXposition + 1390, 110);
        glVertex2f(trainXposition + 1390, 70);
        glVertex2f(trainXposition + 1472, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1110, 110);
        glVertex2f(trainXposition + 1088, 110);
        glVertex2f(trainXposition + 1088, 70);
        glVertex2f(trainXposition + 1110, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1082, 110);
        glVertex2f(trainXposition + 1060, 110);
        glVertex2f(trainXposition + 1060, 70);
        glVertex2f(trainXposition + 1082, 70);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1085, 120);
        glVertex2f(trainXposition + 1085, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1055, 120);
        glVertex2f(trainXposition + 1055, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1115, 120);
        glVertex2f(trainXposition + 1115, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1115, 120);
        glVertex2f(trainXposition + 1055, 120);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1115, 20);
        glVertex2f(trainXposition + 1055, 20);
        glEnd();










        //Train ->End



        glBegin(GL_QUADS); //Ground Floor Concrete
        glColor3f(0.85, 0.85, 0.85);
        glVertex2f(960, -195);
        glVertex2f(560, -195);
        glVertex2f(560, -205);
        glVertex2f(960, -205);
        glEnd();


        glBegin(GL_QUADS); //Ground Floor Concrete
        glColor3f(0.7, 0.7, 0.7);
        glVertex2f(590, -195);
        glVertex2f(560, -195);
        glVertex2f(560, -205);
        glVertex2f(590, -205);
        glEnd();


        //Metro-rail Line

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-987, -24);
        glVertex2f(-987, 14);
        glVertex2f(972, 14);
        glVertex2f(972, -24);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-987, -10);
        glVertex2f(-987, 10);
        glVertex2f(972, 10);
        glVertex2f(972, -10);
        glEnd();



        //1st Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758, -308);
        glVertex2f(-758, -131);
        glVertex2f(-714, -131);
        glVertex2f(-714, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758, -131);
        glVertex2f(-869, -24);
        glVertex2f(-603, -24);
        glVertex2f(-714, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821, -70);
        glVertex2f(-869, -24);
        glVertex2f(-603, -24);
        glVertex2f(-651, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758, -131);
        glVertex2f(-714, -131);
        glVertex2f(-714, -145);
        glVertex2f(-758, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748, -308);
        glVertex2f(-748, -70);
        glVertex2f(-724, -70);
        glVertex2f(-724, -308);
        glEnd();



        //2nd Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459, -308);
        glVertex2f(-758 + 459, -131);
        glVertex2f(-714 + 459, -131);
        glVertex2f(-714 + 459, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459, -131);
        glVertex2f(-869 + 459, -24);
        glVertex2f(-603 + 459, -24);
        glVertex2f(-714 + 459, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821 + 459, -70);
        glVertex2f(-869 + 459, -24);
        glVertex2f(-603 + 459, -24);
        glVertex2f(-651 + 459, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758 + 459, -131);
        glVertex2f(-714 + 459, -131);
        glVertex2f(-714 + 459, -145);
        glVertex2f(-758 + 459, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748 + 459, -308);
        glVertex2f(-748 + 459, -70);
        glVertex2f(-724 + 459, -70);
        glVertex2f(-724 + 459, -308);
        glEnd();


        //3rd Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459, -308);
        glVertex2f(-758 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459, -131);
        glVertex2f(-869 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459, -24);
        glVertex2f(-714 + 459 + 459, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821 + 459 + 459, -70);
        glVertex2f(-869 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459, -24);
        glVertex2f(-651 + 459 + 459, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -145);
        glVertex2f(-758 + 459 + 459, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748 + 459 + 459, -308);
        glVertex2f(-748 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459, -308);
        glEnd();



        //4th Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459 + 459, -308);
        glVertex2f(-758 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459 + 459, -131);
        glVertex2f(-869 + 459 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459 + 459, -24);
        glVertex2f(-714 + 459 + 459 + 459, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821 + 459 + 459 + 459, -70);
        glVertex2f(-869 + 459 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459 + 459, -24);
        glVertex2f(-651 + 459 + 459 + 459, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -145);
        glVertex2f(-758 + 459 + 459 + 459, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748 + 459 + 459 + 459, -308);
        glVertex2f(-748 + 459 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459 + 459, -308);
        glEnd();



const int numSegments = 100; // Number of segments to approximate the circle

int treeXPosition = -670;

// Colors for tree foliage
int treeFoliageColorRed = 34;
int treeFoliageColorGreen = 139;
int treeFoliageColorBlue = 34;
int treeFoliageColorRed2 = 173;
int treeFoliageColorGreen2 = 255;
int treeFoliageColorBlue2 = 47;

for (int i = 0; i < 6; i++) { // Loop for six trees
    if (treeXPosition < 700) {
        // Tree trunk
        glBegin(GL_QUADS);
        glColor3ub(139, 69, 19); // Brown color for trunk
        glVertex2f(treeXPosition - 10, -370); // Increased width
        glVertex2f(treeXPosition + 10, -370); // Increased width
        glVertex2f(treeXPosition + 10, -270); // Increased height
        glVertex2f(treeXPosition - 10, -270); // Increased height
        glEnd();

        // Tree foliage - First circle (bottom layer)
        glBegin(GL_TRIANGLE_FAN);
        glColor3ub(treeFoliageColorRed, treeFoliageColorGreen, treeFoliageColorBlue);
        glVertex2f(treeXPosition, -250); // Center of the circle
        for (int j = 0; j <= numSegments; j++) {
            float angle = 2.0f * M_PI * j / numSegments; // Calculate the angle
            glVertex2f(treeXPosition + cos(angle) * 40, -250 + sin(angle) * 40); // Increased radius to 40
        }
        glEnd();
    }
    treeXPosition += 320; // Adjust the spacing to fit six trees within the desired range
}





 // Draw the river
    glBegin(GL_QUADS);
    glColor3ub(rivercolorred,rivercolorgreen,rivercolorblue); // Sky blue
    glVertex2f(960, -350);
    glVertex2f(-960, -350);

    glColor3ub(rivercolorred1,rivercolorgreen1,rivercolorblue1); // Deep blue
    glVertex2f(-960, -550);
    glVertex2f(960, -550);
    glEnd();
    //draw wave
    glBegin(GL_QUADS);
    for (int x = -960; x < 960; x += 10) {
        float waveHeight = 40 * sin(x * 0.01); // Generate wave using sine function

        // Top part of the wave (lighter blue)
        glColor3ub(135, 206, 250);
        glVertex2f(x, -540 + waveHeight);
        glVertex2f(x + 10, -540 + waveHeight);

        // Bottom part of the wave (deeper blue)
        glColor3ub(0, 100, 200);
        glVertex2f(x + 10, -550);
        glVertex2f(x, -550);
    }
    glEnd();
       glBegin(GL_QUADS);

    // Lower wave (original wave)
    for (int x = -960; x < 960; x += 10) {
        float waveHeight = 40 * sin(x * 0.01); // Generate wave using sine function

        // Top part of the wave (lighter blue)
        glColor3ub(135, 206, 250);
        glVertex2f(x, -540 + waveHeight);
        glVertex2f(x + 10, -540 + waveHeight);

        // Bottom part of the wave (deeper blue)
        glColor3ub(0, 100, 200);
        glVertex2f(x + 10, -550);
        glVertex2f(x, -550);
    }

    // Upper wave
    for (int x = -960; x < 960; x += 10) {
        float waveHeight = 30 * cos(x * 0.015); // Slightly smaller wave with cosine function

        // Top part of the wave (lighter blue)
        glColor3ub(135, 206, 250);
        glVertex2f(x, -440 + waveHeight); // Offset the wave upward
        glVertex2f(x + 10, -440 + waveHeight);

        // Bottom part of the wave (deeper blue)
        glColor3ub(0, 100, 200);
        glVertex2f(x + 10, -450); // Offset the base upward
        glVertex2f(x, -450);
    }

    glEnd();



    // Draw the boat
    glPushMatrix();
    glTranslatef(boatXPosition, -470.0f, 0.0f); // Position the boat on the river

  // Boat body with shading
glBegin(GL_POLYGON);

// Bottom-left vertex (darker brown)
glColor3ub(120, 60, 30);
glVertex2f(-70, 15);

// Bottom-right vertex (darker brown)
glColor3ub(120, 60, 30);
glVertex2f(70, 15);

// Top-right vertex (lighter brown for shading effect)
glColor3ub(160, 82, 45);
glVertex2f(40, -15);

// Top-left vertex (lighter brown for shading effect)
glColor3ub(160, 82, 45);
glVertex2f(-40, -15);

glEnd();

    // Boat sail with shading
glBegin(GL_TRIANGLES);

// Bottom vertex (lighter white)
glColor3ub(255, 255, 255);
glVertex2f(0, 15);   // Bottom (center of the boat)

// Top vertex (darker white for shading effect)
glColor3ub(230, 230, 230);
glVertex2f(0, 70);   // Top (above the boat)

// Right vertex (intermediate shade of white)
glColor3ub(245, 245, 245);
glVertex2f(40, 15);  // Right (aligned with the bottom edge of the boat)

glEnd();





}    else if (sceneNo == 2) {






        glBegin(GL_POLYGON);

        //Sky
        glColor3f(0.11f, 0.59f, 0.77f);
        glVertex2f(-960.00, 540.00);
        glVertex2f(960.00, 540.00);
        glColor3f(0.63f, 0.85f, 0.94f);
        glVertex2f(960, 21.00);
        glVertex2f(-960.00, 21.00);
        glEnd();
        glColor3f(0, 0, 0);
        glLineWidth(10.0);

        if (environmentState == 0) {


            int SkyRed = 131;   //DAY SKY
            int SkyGreen = 231;
            int SkyBlue = 246;
            glBegin(GL_QUADS);
            glColor3ub(SkyRed, SkyGreen, SkyBlue); //TOP gradient
            glVertex2f(960, 540);
            glVertex2f(-960, 540);
            glColor3ub(SkyRed + 124, SkyGreen + 24, SkyBlue + 9);//Bottom Gradient
            glVertex2f(-960, -0);
            glVertex2f(960, -0);
            glEnd();


            trainBaseColorRed = 255;
            trainBaseColorGreen = 255;
            trainBaseColorBlue = 255;

            trainBaseColor2Red = 215;
            trainBaseColor2Green = 215;
            trainBaseColor2Blue = 215;

            trainWindowColorRed = 90;
            trainWindowColorGreen = 90;
            trainWindowColorBlue = 90;

            trainBaseGreenColorRed = 0;
            trainBaseGreenColorGreen = 174;
            trainBaseGreenColorBlue = 86;

              car1YellowColorRed = 254;
            car1YellowColorGreen = 185;
            car1YellowColorBlue = 1;

            car1BlackColorRed = 72;
            car1BlackColorGreen = 72;
            car1BlackColorBlue = 72;


            car2GreenColorRed = 34;
            car2GreenColorGreen = 139;
            car2GreenColorBlue = 34;



            car4WhiteColorRed = 255;
            car4WhiteColorGreen = 255;
            car4WhiteColorBlue = 255;

            truck2BluecolorRed = 1;
            truck2BluecolorGreen = 142;
            truck2BluecolorBlue = 230;




            truck1RedcolorRed = 221;
            truck1RedcolorGreen = 67;
            truck1RedcolorBlue = 55;


            truck2BluecolorRed = 1;
            truck2BluecolorGreen = 142;
            truck2BluecolorBlue = 230;



            cloudColorRed = 255;
            cloudColorGreen = 255;
            cloudColorBlue = 255;



        }
        else {

            int SkyRed = 13;    //NIGHT SKY
            int SkyGreen = 20;
            int SkyBlue = 69;
            glBegin(GL_QUADS);
            glColor3ub(SkyRed, SkyGreen, SkyBlue); //Top Gradient
            glVertex2f(960, 540);
            glVertex2f(-960, 540);


            glColor3ub(SkyRed + 79, SkyGreen + 64, SkyBlue + 95);//Bottom Gradient
            glVertex2f(-960, 0);
            glVertex2f(960, 0);
            glEnd();



            cloudColorRed = 3;
            cloudColorGreen = 104;
            cloudColorBlue = 192;


            trainBaseColorRed = 75;
            trainBaseColorGreen = 75;
            trainBaseColorBlue = 75;

            trainBaseColor2Red = 45;
            trainBaseColor2Green = 45;
            trainBaseColor2Blue = 45;

            trainWindowColorRed = 255;
            trainWindowColorGreen = 249;
            trainWindowColorBlue = 196;


            trainBaseGreenColorRed = 17;
            trainBaseGreenColorGreen = 81;
            trainBaseGreenColorBlue = 49;



        }


        //Cloud

        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud1Position, 400);
        glVertex2f(cloud1Position - 200, 400);
        glVertex2f(cloud1Position - 200, 350);
        glVertex2f(cloud1Position, 350);
        glEnd();

        drawCircle4(cloud1Position - 200, 400, 50);
        drawCircle4(cloud1Position, 410, 60);
        drawCircle4(cloud1Position - 100, 430, 80);



        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud2Position, 270);
        glVertex2f(cloud2Position - 150, 270);
        glVertex2f(cloud2Position - 150, 220);
        glVertex2f(cloud2Position, 220);
        glEnd();

        drawCircle4(cloud2Position - 150, 270, 50);
        drawCircle4(cloud2Position, 260, 40);
        drawCircle4(cloud2Position - 80, 280, 60);


        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud3Position, 380);
        glVertex2f(cloud3Position - 150, 380);
        glVertex2f(cloud3Position - 150, 330);
        glVertex2f(cloud3Position, 330);
        glEnd();

        drawCircle4(cloud3Position - 150, 380, 50);
        drawCircle4(cloud3Position, 390, 60);
        drawCircle4(cloud3Position - 80, 390, 60);






        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud4Position, 320);
        glVertex2f(cloud4Position - 200, 320);
        glVertex2f(cloud4Position - 200, 270);
        glVertex2f(cloud4Position, 270);
        glEnd();

        drawCircle4(cloud4Position - 200, 320, 50);
        drawCircle4(cloud4Position, 330, 60);
        drawCircle4(cloud4Position - 100, 350, 80);



        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud5Position, 400);
        glVertex2f(cloud5Position - 150, 400);
        glVertex2f(cloud5Position - 150, 350);
        glVertex2f(cloud5Position, 350);
        glEnd();

        drawCircle4(cloud5Position - 150, 400, 50);
        drawCircle4(cloud5Position, 400, 50);
        drawCircle4(cloud5Position - 80, 420, 70);


        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud6Position, 290);
        glVertex2f(cloud6Position - 150, 290);
        glVertex2f(cloud6Position - 150, 240);
        glVertex2f(cloud6Position, 240);
        glEnd();

        drawCircle4(cloud6Position - 150, 290, 50);
        drawCircle4(cloud6Position, 300, 60);
        drawCircle4(cloud6Position - 80, 300, 60);



 //Mountains
      // First Duplicate Mountain (Leftmost Position - Brown Backside)
glBegin(GL_POLYGON);
glColor3f(0.13f, 0.55f, 0.13f);
glVertex2f(-1400.00, 21.00);
glVertex2f(-1174.00, 182.00);
glVertex2f(-1168.00, 172.00);
glVertex2f(-1015.00, 277.00);
glVertex2f(-1006.00, 265.00);
glVertex2f(-862.00, 370.00);
glVertex2f(-691.00, 270.00);
glVertex2f(-681.00, 281.00);
glVertex2f(-524.00, 172.00);
glVertex2f(-512.00, 186.00);
glVertex2f(-277.00, 21.00);
glEnd();

// First Duplicate Mountain (Leftmost Position - Green Frontside)
glBegin(GL_POLYGON);
glColor3f(0.56f, 0.30f, 0.31f);
glVertex2f(-1400.00, 21.00);
glVertex2f(-1174.00, 182.00);
glVertex2f(-1168.00, 172.00);
glVertex2f(-1015.00, 277.00);
glVertex2f(-1006.00, 265.00);
glVertex2f(-862.00, 370.00);
glVertex2f(-691.00, 270.00);
glVertex2f(-681.00, 281.00);
glVertex2f(-524.00, 172.00);
glVertex2f(-512.00, 186.00);
glVertex2f(-277.00, 21.00);
glEnd();

// Second Duplicate Mountain (Leftmost Position - Brown Backside)
glBegin(GL_POLYGON);
glColor3f(0.310f, 0.212f, 0.051f);
glVertex2f(-1780.00, 21.00);
glVertex2f(-1554.00, 182.00);
glVertex2f(-1548.00, 172.00);
glVertex2f(-1395.00, 277.00);
glVertex2f(-1386.00, 265.00);
glVertex2f(-1242.00, 370.00);
glVertex2f(-1071.00, 270.00);
glVertex2f(-1061.00, 281.00);
glVertex2f(-904.00, 172.00);
glVertex2f(-892.00, 186.00);
glVertex2f(-657.00, 21.00);
glEnd();

// Second Duplicate Mountain (Leftmost Position - Green Frontside)
glBegin(GL_POLYGON);
glColor3f(0.498f, 0.376f, 0.184f);
glVertex2f(-1780.00, 21.00);
glVertex2f(-1554.00, 182.00);
glVertex2f(-1548.00, 172.00);
glVertex2f(-1395.00, 277.00);
glVertex2f(-1386.00, 265.00);
glVertex2f(-1242.00, 370.00);
glVertex2f(-1071.00, 270.00);
glVertex2f(-1061.00, 281.00);
glVertex2f(-904.00, 172.00);
glVertex2f(-892.00, 186.00);
glVertex2f(-657.00, 21.00);
glEnd();

// Smaller Mountain in Front of Second Leftmost Mountain
glBegin(GL_POLYGON);
glColor3f(0.56f, 0.30f, 0.31f);
glVertex2f(-1600.00, 21.00);
glVertex2f(-1450.00, 120.00);
glVertex2f(-1400.00, 100.00);
glVertex2f(-1300.00, 140.00);
glVertex2f(-1200.00, 90.00);
glVertex2f(-1100.00, 110.00);
glVertex2f(-1000.00, 21.00);
glEnd();

// Green Hill in front of Second Leftmost Mountain (Smaller Size)
glBegin(GL_POLYGON);
glColor3f(0.671f, 0.541f, 0.325f);
glVertex2f(-1700.00, 21.00);
glVertex2f(-1550.00, 60.00);
glVertex2f(-1450.00, 50.00);
glVertex2f(-1350.00, 70.00);
glVertex2f(-1250.00, 55.00);
glVertex2f(-1150.00, 65.00);
glVertex2f(-1050.00, 21.00);
glEnd();

// Existing Mountains
glBegin(GL_POLYGON);
glColor3f(0.56f, 0.30f, 0.31f);
glVertex2f(-68.00, 21.00);
glVertex2f(228, 241.00);
glVertex2f(240.00, 201.00);
glVertex2f(398.00, 307.00);
glVertex2f(548.00, 210.00);
glVertex2f(557.00, 220.00);
glVertex2f(841.00, 22.00);
glEnd();

glBegin(GL_POLYGON);
glColor3f(0.56f, 0.30f, 0.31f);
glVertex2f(512.00, 21.00);
glVertex2f(836, 320.00);
glVertex2f(847.00, 311.00);
glVertex2f(960.00, 428.00);
glVertex2f(960.00, 21.00);
glEnd();

// Green Hills
glBegin(GL_POLYGON);
glColor3f(0.671f, 0.541f, 0.325f);
glVertex2f(-960.00, 21.00);
glVertex2f(-693.00, 162.00);
glVertex2f(-682.00, 157.00);
glVertex2f(-500.00, 279.00);
glVertex2f(-255.00, 160.00);
glVertex2f(-211.00, 121.00);
glVertex2f(-42.00, 21.00);
glEnd();

glBegin(GL_POLYGON);
glColor3f(0.671f, 0.541f, 0.325f);
glVertex2f(118.00, 21.00);
glVertex2f(248.00, 112.00);
glVertex2f(270.00, 106.00);
glVertex2f(404.00, 207.00);
glVertex2f(583.00, 95.00);
glVertex2f(597.00, 104.00);
glVertex2f(744.00, 21.00);
glEnd();

glBegin(GL_POLYGON);
glColor3f(0.671f, 0.541f, 0.325f);
glVertex2f(707.00, 21.00);
glVertex2f(960.00, 257.00);
glVertex2f(960.00, 21.00);
glEnd();


        //River UpperShade

        glBegin(GL_QUADS);
        glColor3f(0.11f, 0.64f, 0.93f);
        glVertex2f(-960.00, 21.00);
        glVertex2f(960.00, 21.00);
        glVertex2f(960.00, -540.00);
        glVertex2f(-960.00, -540.00);
        glEnd();




        //Metro-rail Line

 glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-987, -24);
        glVertex2f(-987, 14);
        glVertex2f(972, 14);
        glVertex2f(972, -24);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-987, -10);
        glVertex2f(-987, 10);
        glVertex2f(972, 10);
        glVertex2f(972, -10);
        glEnd();



        //1st Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758, -308);
        glVertex2f(-758, -131);
        glVertex2f(-714, -131);
        glVertex2f(-714, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758, -131);
        glVertex2f(-869, -24);
        glVertex2f(-603, -24);
        glVertex2f(-714, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821, -70);
        glVertex2f(-869, -24);
        glVertex2f(-603, -24);
        glVertex2f(-651, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758, -131);
        glVertex2f(-714, -131);
        glVertex2f(-714, -145);
        glVertex2f(-758, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748, -308);
        glVertex2f(-748, -70);
        glVertex2f(-724, -70);
        glVertex2f(-724, -308);
        glEnd();



        //2nd Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459, -308);
        glVertex2f(-758 + 459, -131);
        glVertex2f(-714 + 459, -131);
        glVertex2f(-714 + 459, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459, -131);
        glVertex2f(-869 + 459, -24);
        glVertex2f(-603 + 459, -24);
        glVertex2f(-714 + 459, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821 + 459, -70);
        glVertex2f(-869 + 459, -24);
        glVertex2f(-603 + 459, -24);
        glVertex2f(-651 + 459, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758 + 459, -131);
        glVertex2f(-714 + 459, -131);
        glVertex2f(-714 + 459, -145);
        glVertex2f(-758 + 459, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748 + 459, -308);
        glVertex2f(-748 + 459, -70);
        glVertex2f(-724 + 459, -70);
        glVertex2f(-724 + 459, -308);
        glEnd();


        //3rd Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459, -308);
        glVertex2f(-758 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459, -131);
        glVertex2f(-869 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459, -24);
        glVertex2f(-714 + 459 + 459, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821 + 459 + 459, -70);
        glVertex2f(-869 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459, -24);
        glVertex2f(-651 + 459 + 459, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459, -145);
        glVertex2f(-758 + 459 + 459, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748 + 459 + 459, -308);
        glVertex2f(-748 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459, -308);
        glEnd();



        //4th Metro Rail Bridge
        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459 + 459, -308);
        glVertex2f(-758 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -308);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.4980f, 0.5059f, 0.5059f);
        glVertex2f(-758 + 459 + 459 + 459, -131);
        glVertex2f(-869 + 459 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459 + 459, -24);
        glVertex2f(-714 + 459 + 459 + 459, -131);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-821 + 459 + 459 + 459, -70);
        glVertex2f(-869 + 459 + 459 + 459, -24);
        glVertex2f(-603 + 459 + 459 + 459, -24);
        glVertex2f(-651 + 459 + 459 + 459, -70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-758 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -131);
        glVertex2f(-714 + 459 + 459 + 459, -145);
        glVertex2f(-758 + 459 + 459 + 459, -145);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.2824f, 0.2824f, 0.2824f);
        glVertex2f(-748 + 459 + 459 + 459, -308);
        glVertex2f(-748 + 459 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459 + 459, -70);
        glVertex2f(-724 + 459 + 459 + 459, -308);
        glEnd();


        //Train -Begin

        //Body1

        glBegin(GL_POLYGON); //Train Base
        glColor3ub(trainBaseColorRed, trainBaseColorGreen, trainBaseColorBlue);
        glVertex2f(trainXposition + 435, 130);
        glVertex2f(trainXposition, 130);
        glVertex2f(trainXposition - 20, 120);
        glVertex2f(trainXposition - 70, 60);
        glVertex2f(trainXposition - 70, 25);
        glVertex2f(trainXposition - 50, 5);
        glVertex2f(trainXposition, 0);
        glVertex2f(trainXposition + 420, 0);
        glVertex2f(trainXposition + 450, 25);
        glVertex2f(trainXposition + 450, 120);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainBaseColor2Red, trainBaseColor2Green, trainBaseColor2Blue);
        glVertex2f(trainXposition + 450, 120);
        glVertex2f(trainXposition - 20, 120);
        glVertex2f(trainXposition - 70, 60);
        glVertex2f(trainXposition + 450, 60);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(trainBaseGreenColorRed, trainBaseGreenColorGreen, trainBaseGreenColorBlue);
        glVertex2f(trainXposition + 450, 30);
        glVertex2f(trainXposition - 70, 30);
        glVertex2f(trainXposition - 70, 25);
        glVertex2f(trainXposition - 50, 0);
        glVertex2f(trainXposition + 420, 0);
        glVertex2f(trainXposition + 450, 25);
        glEnd();

        //Windows
        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 20, 110);
        glVertex2f(trainXposition - 28, 110);
        glVertex2f(trainXposition - 62, 70);
        glVertex2f(trainXposition + 20, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 110, 110);
        glVertex2f(trainXposition + 30, 110);
        glVertex2f(trainXposition + 30, 70);
        glVertex2f(trainXposition + 110, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 200, 110);
        glVertex2f(trainXposition + 120, 110);
        glVertex2f(trainXposition + 120, 70);
        glVertex2f(trainXposition + 200, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 290, 110);
        glVertex2f(trainXposition + 210, 110);
        glVertex2f(trainXposition + 210, 70);
        glVertex2f(trainXposition + 290, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 440, 110);
        glVertex2f(trainXposition + 360, 110);
        glVertex2f(trainXposition + 360, 70);
        glVertex2f(trainXposition + 440, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 322, 110);
        glVertex2f(trainXposition + 300, 110);
        glVertex2f(trainXposition + 300, 70);
        glVertex2f(trainXposition + 322, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 350, 110);
        glVertex2f(trainXposition + 328, 110);
        glVertex2f(trainXposition + 328, 70);
        glVertex2f(trainXposition + 350, 70);
        glEnd();


        glLineWidth(2.0f);
        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 325.5, 120);
        glVertex2f(trainXposition + 325.5, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 295, 120);
        glVertex2f(trainXposition + 295, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 355, 120);
        glVertex2f(trainXposition + 355, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 355, 120);
        glVertex2f(trainXposition + 295, 120);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 355, 20);
        glVertex2f(trainXposition + 295, 20);
        glEnd();



        //Body2

        glBegin(GL_POLYGON); //Train Base
        glColor3ub(trainBaseColorRed, trainBaseColorGreen, trainBaseColorBlue);
        glVertex2f(trainXposition + 935, 130);
        glVertex2f(trainXposition + 480, 130);
        glVertex2f(trainXposition + 460, 120);
        glVertex2f(trainXposition + 460, 25);
        glVertex2f(trainXposition + 480, 0);
        glVertex2f(trainXposition + 920, 0);
        glVertex2f(trainXposition + 950, 25);
        glVertex2f(trainXposition + 950, 120);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainBaseColor2Red, trainBaseColor2Green, trainBaseColor2Blue);
        glVertex2f(trainXposition + 950, 120);
        glVertex2f(trainXposition + 460, 120);
        glVertex2f(trainXposition + 460, 60);
        glVertex2f(trainXposition + 950, 60);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(trainBaseGreenColorRed, trainBaseGreenColorGreen, trainBaseGreenColorBlue);
        glVertex2f(trainXposition + 950, 30);
        glVertex2f(trainXposition + 460, 30);
        glVertex2f(trainXposition + 460, 25);
        glVertex2f(trainXposition + 480, 0);
        glVertex2f(trainXposition + 920, 0);
        glVertex2f(trainXposition + 950, 25);
        glEnd();



        //Windows

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 550, 110);
        glVertex2f(trainXposition + 470, 110);
        glVertex2f(trainXposition + 470, 70);
        glVertex2f(trainXposition + 550, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 640, 110);
        glVertex2f(trainXposition + 560, 110);
        glVertex2f(trainXposition + 560, 70);
        glVertex2f(trainXposition + 640, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 730, 110);
        glVertex2f(trainXposition + 650, 110);
        glVertex2f(trainXposition + 650, 70);
        glVertex2f(trainXposition + 730, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 820, 110);
        glVertex2f(trainXposition + 740, 110);
        glVertex2f(trainXposition + 740, 70);
        glVertex2f(trainXposition + 820, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 850, 110);
        glVertex2f(trainXposition + 830, 110);
        glVertex2f(trainXposition + 830, 70);
        glVertex2f(trainXposition + 850, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 876, 110);
        glVertex2f(trainXposition + 856, 110);
        glVertex2f(trainXposition + 856, 70);
        glVertex2f(trainXposition + 876, 70);
        glEnd();


        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 853.5, 120);
        glVertex2f(trainXposition + 853.5, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 825, 120);
        glVertex2f(trainXposition + 825, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 881, 120);
        glVertex2f(trainXposition + 881, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 881, 120);
        glVertex2f(trainXposition + 825, 120);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 881, 20);
        glVertex2f(trainXposition + 825, 20);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 940, 110);
        glVertex2f(trainXposition + 886, 110);
        glVertex2f(trainXposition + 886, 70);
        glVertex2f(trainXposition + 940, 70);
        glEnd();



        //Body3

        glBegin(GL_POLYGON); //Train Base
        glColor3ub(trainBaseColorRed, trainBaseColorGreen, trainBaseColorBlue);
        glVertex2f(trainXposition + 1410, 130);
        glVertex2f(trainXposition + 980, 130);
        glVertex2f(trainXposition + 960, 120);

        glVertex2f(trainXposition + 960, 25);
        glVertex2f(trainXposition + 980, 0);
        glVertex2f(trainXposition + 1460, 0);
        glVertex2f(trainXposition + 1480, 25);
        glVertex2f(trainXposition + 1480, 60);
        glVertex2f(trainXposition + 1430, 120);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(trainBaseColor2Red, trainBaseColor2Green, trainBaseColor2Blue);
        glVertex2f(trainXposition + 1430, 120);
        glVertex2f(trainXposition + 960, 120);
        glVertex2f(trainXposition + 960, 60);
        glVertex2f(trainXposition + 1480, 60);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(trainBaseGreenColorRed, trainBaseGreenColorGreen, trainBaseGreenColorBlue);
        glVertex2f(trainXposition + 1480, 30);
        glVertex2f(trainXposition + 960, 30);
        glVertex2f(trainXposition + 960, 25);
        glVertex2f(trainXposition + 980, 0);
        glVertex2f(trainXposition + 1460, 0);
        glVertex2f(trainXposition + 1480, 25);
        glVertex2f(trainXposition + 1480, 30);


        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1050, 110);
        glVertex2f(trainXposition + 970, 110);
        glVertex2f(trainXposition + 970, 70);
        glVertex2f(trainXposition + 1050, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1200, 110);
        glVertex2f(trainXposition + 1120, 110);
        glVertex2f(trainXposition + 1120, 70);
        glVertex2f(trainXposition + 1200, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1290, 110);
        glVertex2f(trainXposition + 1210, 110);
        glVertex2f(trainXposition + 1210, 70);
        glVertex2f(trainXposition + 1290, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1380, 110);
        glVertex2f(trainXposition + 1300, 110);
        glVertex2f(trainXposition + 1300, 70);
        glVertex2f(trainXposition + 1380, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1440, 110);
        glVertex2f(trainXposition + 1390, 110);
        glVertex2f(trainXposition + 1390, 70);
        glVertex2f(trainXposition + 1472, 70);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1110, 110);
        glVertex2f(trainXposition + 1088, 110);
        glVertex2f(trainXposition + 1088, 70);
        glVertex2f(trainXposition + 1110, 70);
        glEnd();


        glBegin(GL_QUADS);
        glColor3ub(trainWindowColorRed, trainWindowColorGreen, trainWindowColorBlue);
        glVertex2f(trainXposition + 1082, 110);
        glVertex2f(trainXposition + 1060, 110);
        glVertex2f(trainXposition + 1060, 70);
        glVertex2f(trainXposition + 1082, 70);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1085, 120);
        glVertex2f(trainXposition + 1085, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1055, 120);
        glVertex2f(trainXposition + 1055, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1115, 120);
        glVertex2f(trainXposition + 1115, 20);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1115, 120);
        glVertex2f(trainXposition + 1055, 120);
        glEnd();

        glBegin(GL_LINES);
        glColor3b(50, 50, 50);
        glVertex2f(trainXposition + 1115, 20);
        glVertex2f(trainXposition + 1055, 20);
        glEnd();






        //Train ->End


        //First Boat

        glPushMatrix();
        glTranslatef(position3, 0.0f, 0.0f);

        glBegin(GL_QUADS);
        glColor3f(0.11f, 0.20f, 0.32f);
        glVertex2f(-650.00, -293.00 - 45);
        glVertex2f(-650.00, -235.00 - 45);
        glVertex2f(-336.00, -223.00 - 45);
        glVertex2f(-388.00, -293.00 - 45);
        glEnd();

        glBegin(GL_TRIANGLES);
        glColor3f(0.96f, 0.95f, 0.85f);
        glVertex2f(-548.00, -231.00 - 45);
        glVertex2f(-428.00, -146.00 - 45);
        glVertex2f(-428.00, -226.00 - 45);
        glVertex2f(-548.00, -231.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.91f, 0.32f, 0.29f);
        glVertex2f(-592.00, -233.00 - 45);
        glVertex2f(-592.00, -153.00 - 45);
        glVertex2f(-570.00, -153.00 - 45);
        glVertex2f(-570.00, -232.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.84f, 0.74f, 0.37f);
        glVertex2f(-381.00, -224.00 - 45);
        glVertex2f(-381.00, -182.00 - 45);
        glVertex2f(-360.00, -182.00 - 45);
        glVertex2f(-360.00, -224.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.91f, 0.32f, 0.29f);
        glVertex2f(-560.00, -233.00 - 45);
        glVertex2f(-560.00, -169.00 - 45);
        glVertex2f(-538.00, -169.00 - 45);
        glVertex2f(-538.00, -233.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.91f, 0.32f, 0.29f);
        glVertex2f(-528.00, -232.00 - 45);
        glVertex2f(-528.00, -142.00 - 45);
        glVertex2f(-505.00, -142.00 - 45);
        glVertex2f(-505.00, -229.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.91f, 0.32f, 0.29f);
        glVertex2f(-494.00, -230.00 - 45);
        glVertex2f(-494.00, -120.00 - 45);
        glVertex2f(-471.00, -120.00 - 45);
        glVertex2f(-471.00, -228.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.69f, 0.76f, 0.72f);
        glVertex2f(-538.00, -274.00 - 45);
        glVertex2f(-538.00, -251.00 - 45);
        glVertex2f(-514.00, -251.00 - 45);
        glVertex2f(-514.00, -274.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.69f, 0.76f, 0.72f);
        glVertex2f(-538.00 + 34, -274.00 - 45);
        glVertex2f(-538.00 + 34, -251.00 - 45);
        glVertex2f(-514.00 + 34, -251.00 - 45);
        glVertex2f(-514.00 + 34, -274.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.69f, 0.76f, 0.72f);
        glVertex2f(-538.00 + 34 + 34, -274.00 - 45);
        glVertex2f(-538.00 + 34 + 34, -251.00 - 45);
        glVertex2f(-514.00 + 34 + 34, -251.00 - 45);
        glVertex2f(-514.00 + 34 + 34, -274.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.69f, 0.76f, 0.72f);
        glVertex2f(-538.00 + 34 + 34 + 34, -274.00 - 45);
        glVertex2f(-538.00 + 34 + 34 + 34, -251.00 - 45);
        glVertex2f(-514.00 + 34 + 34 + 34, -251.00 - 45);
        glVertex2f(-514.00 + 34 + 34 + 34, -274.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.69f, 0.76f, 0.72f);
        glVertex2f(-538.00 - 34, -274.00 - 45);
        glVertex2f(-538.00 - 34, -251.00 - 45);
        glVertex2f(-514.00 - 34, -251.00 - 45);
        glVertex2f(-514.00 - 34, -274.00 - 45);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.69f, 0.76f, 0.72f);
        glVertex2f(-538.00 - 34 - 34, -274.00 - 45);
        glVertex2f(-538.00 - 34 - 34, -251.00 - 45);
        glVertex2f(-514.00 - 34 - 34, -251.00 - 45);
        glVertex2f(-514.00 - 34 - 34, -274.00 - 45);
        glEnd();

        glPopMatrix();

        //1st Wave Shade

        glBegin(GL_QUADS);
        glColor3f(0.10f, 0.58f, 0.83f);
        glVertex2f(-960, -344);
        glVertex2f(960, -344);
        glVertex2f(960, -540);
        glVertex2f(-960, -540);
        glEnd();


        glPushMatrix();
        glTranslatef(position2, 0.0f, 0.0f);

        glBegin(GL_POLYGON);
        glColor3f(0.10f, 0.58f, 0.83f);

        int x1 = -1627;
        int y1 = -344;
        int width1 = 66;

        while (x1 < 2500) {
            glBegin(GL_POLYGON);
            glVertex2f(x1, y1);
            glVertex2f(x1 + width1, y1 + 18);
            glVertex2f(x1 + width1, y1);
            glEnd();

            x1 += width1;
        }

        glPopMatrix();

        //2nd Boat

        glPushMatrix();
        glTranslatef(position1, 0.0f, 0.0f);

        glBegin(GL_POLYGON);
        glColor3f(0.03f, 0.04f, 0.13f);
        glVertex2f(-165 + 1086, -343);
        glVertex2f(548 + 1086, -386);
        glVertex2f(549 + 1086, -426);
        glVertex2f(513 + 1086, -460);
        glVertex2f(-39 + 1086, -460);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3f(1.0, 1.0f, 1.0f);
        glVertex2f(-79 + 1086, -349);
        glVertex2f(-8 + 1086, -220);
        glVertex2f(498 + 1086, -255);
        glVertex2f(483 + 1086, -330);
        glVertex2f(522 + 1086, -331);
        glVertex2f(513 + 1086, -384);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.28f, 0.77f, 0.99f);
        glVertex2f(-16 + 1086, -234);
        glVertex2f(479 + 1086, -268);
        glVertex2f(469 + 1086, -314);
        glVertex2f(-40 + 1086, -278);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.28f, 0.77f, 0.99f);
        glVertex2f(-47 + 1086, -290);
        glVertex2f(469 + 1086, -330);
        glVertex2f(459 + 1086, -372);
        glVertex2f(-72 + 1086, -336);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.71f, 0.13f, 0.04f);
        glVertex2f(78 + 1086, -226);
        glVertex2f(86 + 1086, -162);
        glVertex2f(115 + 1086, -166);
        glVertex2f(107 + 1086, -228);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.52f, 0.52f, 0.52f);
        glVertex2f(83 + 1086, -184);
        glVertex2f(112 + 1086, -188);
        glVertex2f(111 + 1086, -200);
        glVertex2f(82 + 1086, -196);
        glEnd();


        glBegin(GL_QUADS);
        glColor3f(0.71f, 0.13f, 0.04f);
        glVertex2f(137 + 1086, -230);
        glVertex2f(144 + 1086, -170);
        glVertex2f(173 + 1086, -173);
        glVertex2f(167 + 1086, -232);
        glEnd();

        glBegin(GL_QUADS);
        glColor3f(0.52f, 0.52f, 0.52f);
        glVertex2f(140 + 1086, -204);
        glVertex2f(141 + 1086, -191);
        glVertex2f(171 + 1086, -195);
        glVertex2f(169 + 1086, -208);
        glEnd();

        glPopMatrix();



        //2md wave shade

        glBegin(GL_QUADS);
        glColor3f(0.08f, 0.51f, 0.74f);
        glVertex2f(-960, -460);
        glVertex2f(960, -460);
        glVertex2f(960, -540);
        glVertex2f(-960, -540);
        glEnd();


        glPushMatrix();
        glTranslatef(position2, 0.0f, 0.0f);

        glBegin(GL_POLYGON);
        glColor3f(0.08f, 0.51f, 0.74f);

        int x = -1628;
        int y = -460;
        int width = 66;

        while (x < 2400) {
            glBegin(GL_POLYGON);
            glVertex2f(x, y);
            glVertex2f(x + width, y + 18);
            glVertex2f(x + width, y);
            glEnd();

            x += width;
        }

        glPopMatrix();

    }






   else if (sceneNo == 3) {

        // Background Color for Scene 3
        glBegin(GL_QUADS);
        glColor3ub(100, 100, 255); // Sky blue
        glVertex2f(960, 540);
        glVertex2f(-960, 540);
        glColor3ub(50, 50, 150); // Darker shade
        glVertex2f(-960, -300);
        glVertex2f(960, -300);
        glEnd();

        // Example: Adding a simple rectangle as a placeholder for Scene 3 content
        glBegin(GL_QUADS);
        glColor3ub(200, 0, 0); // Red rectangle
        glVertex2f(-200, -100);
        glVertex2f(200, -100);
        glVertex2f(200, -300);
        glVertex2f(-200, -300);
        glEnd();

        // Add other scene elements like buildings, clouds, train, etc.

  if (environmentState == 0) {


            int SkyRed = 131;   //DAY SKY
            int SkyGreen = 231;
            int SkyBlue = 246;
            glBegin(GL_QUADS);
            glColor3ub(SkyRed, SkyGreen, SkyBlue); //TOP gradient
            glVertex2f(960, 540);
            glVertex2f(-960, 540);
            glColor3ub(SkyRed + 124, SkyGreen + 24, SkyBlue + 9);//Bottom Gradient
            glVertex2f(-960, -300);
            glVertex2f(960, -300);
            glEnd();



            BuildingWhiteColorRed = 255;
            BuildingWhiteColorGreen = 255;
            BuildingWhiteColorBlue = 255;

             BuildingWhiteColorRed5 = 25;
            BuildingWhiteColorGreen5 = 94;
            BuildingWhiteColorBlue5 = 94;

           BuildingWhiteColorRed1 = 230;
           BuildingWhiteColorGreen1 = 230;
           BuildingWhiteColorBlue1 = 250;

           BuildingWhiteColorRed2 = 255;
           BuildingWhiteColorGreen2 = 203;
           BuildingWhiteColorBlue2 = 199;

           BuildingWhiteColorRed3 = 246;
           BuildingWhiteColorGreen3 = 209;
           BuildingWhiteColorBlue3 = 119;

           BuildingWhiteColorRed4 = 101;
           BuildingWhiteColorGreen4 = 156;
           BuildingWhiteColorBlue4 = 211;

            BuildingBlueGlassColorRed = 210;
            BuildingBlueGlassColorGreen = 140;
            BuildingBlueGlassColorBlue = 100;

           BuildingBlueGlassColorRed1 = 115;
           BuildingBlueGlassColorGreen1 = 79;
           BuildingBlueGlassColorBlue1 = 150;

           BuildingBlueGlassColorRed2 = 128;
           BuildingBlueGlassColorGreen2 = 0;
           BuildingBlueGlassColorBlue2 = 0;

           BuildingBlueGlassColorRed3 = 167;
           BuildingBlueGlassColorGreen3 = 88;
           BuildingBlueGlassColorBlue3 = 103;

           BuildingBlueGlassColorRed4 = 40;
           BuildingBlueGlassColorGreen4 = 57;
           BuildingBlueGlassColorBlue4 = 129;





            BackgroundBuilding1ColorRed = 75;
            BackgroundBuilding1ColorGreen = 105;
            BackgroundBuilding1ColorBlue = 135;


            BackgroundBuilding2ColorRed = 134;
            BackgroundBuilding2ColorGreen = 116;
            BackgroundBuilding2ColorBlue = 65;

            mainBuildingColorRed = 22;
            mainBuildingColorGreen = 109;
            mainBuildingColorBlue = 122;


            mainBuildingWindowColorRed = 91;
            mainBuildingWindowColorGreen = 182;
            mainBuildingWindowColorBlue = 182;


            grassColorRed = 159;
            grassColorGreen = 217;
            grassColorBlue = 0;

            trainBaseColorRed = 255;
            trainBaseColorGreen = 255;
            trainBaseColorBlue = 255;

            trainBaseColor2Red = 215;
            trainBaseColor2Green = 215;
            trainBaseColor2Blue = 215;

            trainWindowColorRed = 90;
            trainWindowColorGreen = 90;
            trainWindowColorBlue = 90;

            trainBaseGreenColorRed = 0;
            trainBaseGreenColorGreen = 174;
            trainBaseGreenColorBlue = 86;

            trainStationLightColorRed = 193;
            trainStationLightColorGreen = 196;
            trainStationLightColorBlue = 196;

            cloudColorRed = 255;
            cloudColorGreen = 255;
            cloudColorBlue = 255;

            car1YellowColorRed = 254;
            car1YellowColorGreen = 185;
            car1YellowColorBlue = 1;

            car1BlackColorRed = 72;
            car1BlackColorGreen = 72;
            car1BlackColorBlue = 72;


            car2GreenColorRed = 34;
            car2GreenColorGreen = 139;
            car2GreenColorBlue = 34;



            car4WhiteColorRed = 255;
            car4WhiteColorGreen = 255;
            car4WhiteColorBlue = 255;

            truck2BluecolorRed = 1;
            truck2BluecolorGreen = 142;
            truck2BluecolorBlue = 230;




            truck1RedcolorRed = 221;
            truck1RedcolorGreen = 67;
            truck1RedcolorBlue = 55;


            truck2BluecolorRed = 1;
            truck2BluecolorGreen = 142;
            truck2BluecolorBlue = 230;


            sideWalkColorRed = 0.8;
            sideWalkColorGreen = 0.8;
            sideWalkColorBlue = 0.8;

            lampPostLightColorRed = 150;
            lampPostLightColorGreen = 150;
            lampPostLightColorBlue = 150;



        }
        else {

            int SkyRed = 1;    //NIGHT SKY
            int SkyGreen = 2;
            int SkyBlue = 40;
            glBegin(GL_QUADS);
            glColor3ub(SkyRed, SkyGreen, SkyBlue); //Top Gradient
            glVertex2f(960, 540);
            glVertex2f(-960, 540);


            glColor3ub(SkyRed + 1, SkyGreen + 84, SkyBlue + 86);//Bottom Gradient
            glVertex2f(-960, -300);
            glVertex2f(960, -300);
            glEnd();

            srand(5);

            for (int i = 1; i <= 500; i++) {
                int Xrandom = -960 + (rand() % 1921);
                int Yrandom = -540 + (rand() % 1081);
                int Radiusrandom = -3 + (rand() % 6);

                drawCircle(Xrandom, Yrandom, Radiusrandom);

            }






            BuildingWhiteColorRed = 50;
            BuildingWhiteColorGreen = 50;
            BuildingWhiteColorBlue = 50;

                 BuildingBlueGlassColorRed = 210;
           BuildingBlueGlassColorGreen = 140;
           BuildingBlueGlassColorBlue1 = 100;


              BuildingBlueGlassColorRed1 = 0;
           BuildingBlueGlassColorGreen1 = 0;
           BuildingBlueGlassColorBlue1 = 0;

           BuildingBlueGlassColorRed2 = 0;
           BuildingBlueGlassColorGreen2 = 0;
           BuildingBlueGlassColorBlue2 = 0;

           BuildingBlueGlassColorRed3 = 0;
           BuildingBlueGlassColorGreen3 = 0;
           BuildingBlueGlassColorBlue3 = 0;

           BuildingBlueGlassColorRed4 = 0;
           BuildingBlueGlassColorGreen4 = 0;
           BuildingBlueGlassColorBlue4 = 0;



            BackgroundBuilding1ColorRed = 170;
            BackgroundBuilding1ColorGreen = 110;
            BackgroundBuilding1ColorBlue = 80;


            BackgroundBuilding2ColorRed = 130;
            BackgroundBuilding2ColorGreen = 100;
            BackgroundBuilding2ColorBlue = 70;

            mainBuildingColorRed = 50;
            mainBuildingColorGreen = 50;
            mainBuildingColorBlue = 50;


            mainBuildingWindowColorRed = 240;
            mainBuildingWindowColorGreen = 228;
            mainBuildingWindowColorBlue = 130;
            grassColorRed = 11;
            grassColorGreen = 61;
            grassColorBlue = 22;


            trainBaseColorRed = 75;
            trainBaseColorGreen = 75;
            trainBaseColorBlue = 75;

            trainBaseColor2Red = 45;
            trainBaseColor2Green = 45;
            trainBaseColor2Blue = 45;

            trainWindowColorRed = 255;
            trainWindowColorGreen = 249;
            trainWindowColorBlue = 196;


            trainBaseGreenColorRed = 17;
            trainBaseGreenColorGreen = 81;
            trainBaseGreenColorBlue = 49;

            trainStationLightColorRed = 255;
            trainStationLightColorGreen = 196;
            trainStationLightColorBlue = 14;


            car1YellowColorRed = 147;
            car1YellowColorGreen = 107;
            car1YellowColorBlue = 1;


            car2GreenColorRed = 9;
            car2GreenColorGreen = 85;
            car2GreenColorBlue = 9;



            car4WhiteColorRed = 175;
            car4WhiteColorGreen = 175;
            car4WhiteColorBlue = 175;



            cloudColorRed = 3;
            cloudColorGreen = 104;
            cloudColorBlue = 192;

            truck1RedcolorRed = 143;
            truck1RedcolorGreen = 36;
            truck1RedcolorBlue = 28;


            truck2BluecolorRed = 0;
            truck2BluecolorGreen = 92;
            truck2BluecolorBlue = 149;



            sideWalkColorRed = 0.6;
            sideWalkColorGreen = 0.6;
            sideWalkColorBlue = 0.6;



            lampPostLightColorRed = 240;
            lampPostLightColorGreen = 228;
            lampPostLightColorBlue = 130;


        }

        //Cloud

        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud1Position, 400);
        glVertex2f(cloud1Position - 200, 400);
        glVertex2f(cloud1Position - 200, 350);
        glVertex2f(cloud1Position, 350);
        glEnd();

        drawCircle4(cloud1Position - 200, 400, 50);
        drawCircle4(cloud1Position, 410, 60);
        drawCircle4(cloud1Position - 100, 430, 80);



        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud2Position, 270);
        glVertex2f(cloud2Position - 150, 270);
        glVertex2f(cloud2Position - 150, 220);
        glVertex2f(cloud2Position, 220);
        glEnd();

        drawCircle4(cloud2Position - 150, 270, 50);
        drawCircle4(cloud2Position, 260, 40);
        drawCircle4(cloud2Position - 80, 280, 60);


        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud3Position, 380);
        glVertex2f(cloud3Position - 150, 380);
        glVertex2f(cloud3Position - 150, 330);
        glVertex2f(cloud3Position, 330);
        glEnd();

        drawCircle4(cloud3Position - 150, 380, 50);
        drawCircle4(cloud3Position, 390, 60);
        drawCircle4(cloud3Position - 80, 390, 60);






        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud4Position, 320);
        glVertex2f(cloud4Position - 200, 320);
        glVertex2f(cloud4Position - 200, 270);
        glVertex2f(cloud4Position, 270);
        glEnd();

        drawCircle4(cloud4Position - 200, 320, 50);
        drawCircle4(cloud4Position, 330, 60);
        drawCircle4(cloud4Position - 100, 350, 80);



        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud5Position, 400);
        glVertex2f(cloud5Position - 150, 400);
        glVertex2f(cloud5Position - 150, 350);
        glVertex2f(cloud5Position, 350);
        glEnd();

        drawCircle4(cloud5Position - 150, 400, 50);
        drawCircle4(cloud5Position, 400, 50);
        drawCircle4(cloud5Position - 80, 420, 70);


        glBegin(GL_QUADS);
        glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
        glVertex2f(cloud6Position, 290);
        glVertex2f(cloud6Position - 150, 290);
        glVertex2f(cloud6Position - 150, 240);
        glVertex2f(cloud6Position, 240);
        glEnd();

        drawCircle4(cloud6Position - 150, 290, 50);
        drawCircle4(cloud6Position, 300, 60);
        drawCircle4(cloud6Position - 80, 300, 60);


        //Cloud-End



        //    Gradient Sky ->End


        //Green Ground
        glBegin(GL_QUADS);
        glColor3ub(grassColorRed, grassColorGreen, grassColorBlue);
        glVertex2f(960, -200);
        glVertex2f(-960, -200);
        glVertex2f(-960, -540);
        glVertex2f(960, -540);
        glEnd();


        //Asphalt Road

        glBegin(GL_QUADS);
        glColor3ub(100, 100, 100);
        glVertex2f(960, -250);
        glVertex2f(-960, -250);
        glVertex2f(-960, -540);
        glVertex2f(960, -540);
        glEnd();

        //Road Lines

        int Road_Lines_X_Position = -930;

        for (int i = 0; i < 10; i++) {
            if (Road_Lines_X_Position < 930) {
                glBegin(GL_QUADS);
                glColor3f(1.0, 1.0, 1.0);
                glVertex2f(Road_Lines_X_Position + 100, -390); // Adjusted to middle of the road
                glVertex2f(Road_Lines_X_Position, -390);
                glVertex2f(Road_Lines_X_Position, -400);
                glVertex2f(Road_Lines_X_Position + 100, -400);
                glEnd();
                Road_Lines_X_Position += 200;
            }
        }

// Zebra Crossing (Shifted Right)
int Zebra_Y_Position = -210;  // Keeps it in the upper part
int ShiftAmount = 20;  // Move right by 100 units

for (int i = 0; i < 50; i++) { // More stripes to cover the entire road
    glBegin(GL_QUADS);
    glColor3f(1.0, 1.0, 1.0);
    glVertex2f(-25 + ShiftAmount, Zebra_Y_Position);   // Shifted Right
    glVertex2f(25 + ShiftAmount, Zebra_Y_Position);    // Shifted Right
    glVertex2f(25 + ShiftAmount, Zebra_Y_Position - 5);  // Shifted Right
    glVertex2f(-25 + ShiftAmount, Zebra_Y_Position - 5); // Shifted Right
    glEnd();
    Zebra_Y_Position -= 20; // Reduce spacing between stripes for a denser look
}


        //Asphalt Road ->End


        //Sidewalk

        glBegin(GL_QUADS);
        glColor3f(0.5, 0.5, 0.5);
        glVertex2f(960, -200);
        glVertex2f(-960, -200);
        glVertex2f(-960, -258);
        glVertex2f(960, -258);
        glEnd();


        glBegin(GL_QUADS);
        glColor3f(0.8, 0.8, 0.8);
        glVertex2f(960, -180);
        glVertex2f(-960, -180);
        glVertex2f(-960, -240);
        glVertex2f(960, -240);
        glEnd();


        //SideWalk -> Emd


         //Background Building 1

        glBegin(GL_POLYGON);
        glColor3ub(BackgroundBuilding2ColorRed, BackgroundBuilding2ColorGreen, BackgroundBuilding2ColorBlue);
        glVertex2f(950, 350);
        glVertex2f(750, 350);
        glVertex2f(750, -200);
        glVertex2f(950, -200);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(BackgroundBuilding2ColorRed, BackgroundBuilding2ColorGreen, BackgroundBuilding2ColorBlue);
        glVertex2f(920, 380);
        glVertex2f(780, 380);
        glVertex2f(780, 350);
        glVertex2f(920, 350);
        glEnd();


        //Background Building 2

        glBegin(GL_POLYGON);
        glColor3ub(BackgroundBuilding2ColorRed, BackgroundBuilding2ColorGreen, BackgroundBuilding2ColorBlue);
        glVertex2f(720, 400);
        glVertex2f(520, 400);
        glVertex2f(520, -200);
        glVertex2f(720, -200);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(BackgroundBuilding2ColorRed, BackgroundBuilding2ColorGreen, BackgroundBuilding2ColorBlue);
        glVertex2f(720, 420);
        glVertex2f(580, 420);
        glVertex2f(580, 400);
        glVertex2f(720, 400);
        glEnd();




        //Background Building 3

        glBegin(GL_POLYGON);
        glColor3ub(BackgroundBuilding1ColorRed, BackgroundBuilding1ColorGreen, BackgroundBuilding1ColorBlue);
        glVertex2f(850, 250);
        glVertex2f(650, 250);
        glVertex2f(650, -200);
        glVertex2f(850, -200);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(BackgroundBuilding1ColorRed, BackgroundBuilding1ColorGreen, BackgroundBuilding1ColorBlue);
        glVertex2f(800, 280);
        glVertex2f(700, 280);
        glVertex2f(700, 250);
        glVertex2f(800, 250);
        glEnd();



        //Building1 -> From Right

        glBegin(GL_QUADS);
        glColor3ub(BuildingBlueGlassColorRed1, BuildingBlueGlassColorGreen1, BuildingBlueGlassColorBlue1);
        glVertex2f(600, 350);
        glVertex2f(350, 350);
        glVertex2f(350, -200);
        glVertex2f(600, -200);
        glEnd();


        //windows
        int building1_Window_Y_Position = 350;

        for (int i = 0; i < 10; i++) {
            if (building1_Window_Y_Position > -150) {
                glBegin(GL_QUADS);
                glColor3ub(BuildingWhiteColorRed1, BuildingWhiteColorGreen1, BuildingWhiteColorBlue1);
                glVertex2f(600, building1_Window_Y_Position);
                glVertex2f(350, building1_Window_Y_Position);
                glVertex2f(350, building1_Window_Y_Position - 25);
                glVertex2f(600, building1_Window_Y_Position - 25);
                glEnd();
                building1_Window_Y_Position -= 52;
            }
        }

        int building1_Window_Y_Position2 = 325; //for shadow

        for (int j = 0; j < 10; j++) {
            if (building1_Window_Y_Position2 > -150) {
                glBegin(GL_QUADS);
                glColor3ub(BuildingWhiteColorRed1 - 30, BuildingWhiteColorGreen1 - 30, BuildingWhiteColorBlue1 - 30);
                glVertex2f(600, building1_Window_Y_Position2);
                glVertex2f(350, building1_Window_Y_Position2);
                glVertex2f(350, building1_Window_Y_Position2 - 5);
                glVertex2f(600, building1_Window_Y_Position2 - 5);
                glEnd();
                building1_Window_Y_Position2 -= 52;
            }
        }

        glBegin(GL_QUADS);  // Middle pillar
        glColor3ub(BuildingWhiteColorRed1, BuildingWhiteColorGreen1, BuildingWhiteColorBlue1);
        glVertex2f(500, 390);
        glVertex2f(470, 390);
        glVertex2f(470, -200);
        glVertex2f(500, -200);
        glEnd();


        glBegin(GL_QUADS); //rooftop Back
        glColor3ub(BuildingWhiteColorRed - 30, BuildingWhiteColorGreen - 30, BuildingWhiteColorBlue - 30);
        glVertex2f(470, 390);
        glVertex2f(400, 390);
        glVertex2f(400, 350);
        glVertex2f(470, 350);
        glEnd();


        //Building1 -> From Right -> End


        //Building2

        glBegin(GL_QUADS);
        glColor3ub(BuildingBlueGlassColorRed2, BuildingBlueGlassColorGreen2, BuildingBlueGlassColorBlue2);
        glVertex2f(960, 50);
        glVertex2f(580, 50);
        glVertex2f(580, -200);
        glVertex2f(960, -200);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(BuildingBlueGlassColorRed2, BuildingBlueGlassColorGreen2, BuildingBlueGlassColorBlue2);
        glVertex2f(625, 50);
        glVertex2f(580, 50);
        glVertex2f(580, -200);
        glVertex2f(625, -200);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(BuildingBlueGlassColorRed2, BuildingBlueGlassColorGreen2, BuildingBlueGlassColorBlue2);
        glVertex2f(960, 100);
        glVertex2f(700, 100);
        glVertex2f(700, -200);
        glVertex2f(960, -200);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(BuildingBlueGlassColorRed2, BuildingBlueGlassColorGreen2, BuildingBlueGlassColorBlue2);
        glVertex2f(960, 150);
        glVertex2f(750, 150);
        glVertex2f(750, -200);
        glVertex2f(960, -200);
        glEnd();


        glBegin(GL_QUADS); //White Roof Top
        glColor3ub(BuildingWhiteColorRed2, BuildingWhiteColorGreen2, BuildingWhiteColorBlue2);
        glVertex2f(960, 150);
        glVertex2f(740, 150);
        glVertex2f(740, 125);
        glVertex2f(960, 125);
        glEnd();


        glBegin(GL_QUADS); //White Roof Top
        glColor3ub(BuildingWhiteColorRed2, BuildingWhiteColorGreen2, BuildingWhiteColorBlue2);
        glVertex2f(780, 150);
        glVertex2f(740, 150);
        glVertex2f(740, 125);
        glVertex2f(780, 125);
        glEnd();



        glBegin(GL_QUADS); //White Roof Top-1
        glColor3ub(BuildingWhiteColorRed2, BuildingWhiteColorGreen2, BuildingWhiteColorBlue2);
        glVertex2f(960, 100);
        glVertex2f(690, 100);
        glVertex2f(690, 75);
        glVertex2f(960, 75);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(BuildingWhiteColorRed2, BuildingWhiteColorGreen2, BuildingWhiteColorBlue2);
        glVertex2f(730, 100);
        glVertex2f(690, 100);
        glVertex2f(690, 75);
        glVertex2f(730, 75);
        glEnd();


        int building2_roof_y_position = 50;
        for (int j = 0; j < 10; j++) {
            if (building2_roof_y_position > -150) {
                glBegin(GL_QUADS);
                glColor3ub(BuildingWhiteColorRed2, BuildingWhiteColorGreen2, BuildingWhiteColorBlue2);
                glVertex2f(960, building2_roof_y_position);
                glVertex2f(570, building2_roof_y_position);
                glVertex2f(570, building2_roof_y_position - 25);
                glVertex2f(960, building2_roof_y_position - 25);
                glEnd();
                building2_roof_y_position -= 50;

            }
        }

        int building2_roof_y_position2 = 50;  //shadow
        for (int j = 0; j < 10; j++) {
            if (building2_roof_y_position2 > -150) {
                glBegin(GL_QUADS);
                glColor3ub(BuildingWhiteColorRed2, BuildingWhiteColorGreen2, BuildingWhiteColorBlue2);
                glVertex2f(630, building2_roof_y_position2);
                glVertex2f(570, building2_roof_y_position2);
                glVertex2f(570, building2_roof_y_position2 - 25);
                glVertex2f(630, building2_roof_y_position2 - 25);
                glEnd();
                building2_roof_y_position2 -= 50;

            }
        }



        //Building Second left

        glBegin(GL_QUADS);
        glColor3ub(BuildingBlueGlassColorRed3, BuildingBlueGlassColorGreen3, BuildingBlueGlassColorBlue3);
        glVertex2f(-150, 300);
        glVertex2f(-475, 300);
        glVertex2f(-475, -200);
        glVertex2f(-150, -200);
        glEnd();


        //windows
        int building2_left_Window_Y_Position = 300;

        for (int i = 0; i < 10; i++) {
            if (building2_left_Window_Y_Position > -150) {
                glBegin(GL_QUADS);
                glColor3ub(BuildingWhiteColorRed3, BuildingWhiteColorGreen3, BuildingWhiteColorBlue3);
                glVertex2f(-150, building2_left_Window_Y_Position);
                glVertex2f(-475, building2_left_Window_Y_Position);
                glVertex2f(-475, building2_left_Window_Y_Position - 25);
                glVertex2f(-150, building2_left_Window_Y_Position - 25);
                glEnd();
                building2_left_Window_Y_Position -= 52;
            }
        }


        //Building Second left-> End






        //Building Most Left

        glBegin(GL_QUADS);  //Base Layout
        glColor3ub(BuildingBlueGlassColorRed4, BuildingBlueGlassColorGreen4, BuildingBlueGlassColorBlue4);
        glVertex2f(-450, 100);
        glVertex2f(-750, 50);
        glVertex2f(-750, -200);
        glVertex2f(-450, -200);
        glEnd();

        glBegin(GL_QUADS); //Base Layout
        glColor3ub(BuildingBlueGlassColorRed4, BuildingBlueGlassColorGreen4, BuildingBlueGlassColorBlue4);
        glVertex2f(-750, 50);
        glVertex2f(-960, 75);
        glVertex2f(-960, -200);
        glVertex2f(-750, -200);
        glEnd();

        glBegin(GL_TRIANGLES); //Top
        glColor3ub(BuildingWhiteColorRed4, BuildingWhiteColorGreen4, BuildingWhiteColorBlue4);
        glVertex2f(-430, 125);
        glVertex2f(-1000, 110);
        glVertex2f(-750, 75);
        glEnd();

        int mostLeftBuildingWindowYPosition = 60;

        for (int i = 0;i < 6; i++) {
            if (mostLeftBuildingWindowYPosition > -150) {
                glBegin(GL_QUADS); //window
                glColor3ub(BuildingWhiteColorRed4, BuildingWhiteColorGreen4, BuildingWhiteColorBlue4);
                glVertex2f(-450, mostLeftBuildingWindowYPosition);
                glVertex2f(-960, mostLeftBuildingWindowYPosition);
                glVertex2f(-960, mostLeftBuildingWindowYPosition - 5);
                glVertex2f(-450, mostLeftBuildingWindowYPosition - 5);
                glEnd();
            }
            mostLeftBuildingWindowYPosition -= 50;
        }


        int mostLeftBuildingWindowXPosition = -900;

        for (int i = 0;i < 2; i++) {
            if (mostLeftBuildingWindowXPosition < 930) {
                glBegin(GL_QUADS); //window
                glColor3ub(BuildingWhiteColorRed4, BuildingWhiteColorGreen4, BuildingWhiteColorBlue4);
                glVertex2f(mostLeftBuildingWindowXPosition, 75);
                glVertex2f(mostLeftBuildingWindowXPosition - 5, 75);
                glVertex2f(mostLeftBuildingWindowXPosition - 5, -200);
                glVertex2f(mostLeftBuildingWindowXPosition, -200);
                glEnd();
            }
            mostLeftBuildingWindowXPosition += 75;
        }


        int mostLeftBuildingWindowXPosition2 = -675;

        for (int i = 0;i < 4; i++) {
            if (mostLeftBuildingWindowXPosition2 < 930) {
                glBegin(GL_QUADS); //window
                glColor3ub(BuildingWhiteColorRed4, BuildingWhiteColorGreen4, BuildingWhiteColorBlue4);
                glVertex2f(mostLeftBuildingWindowXPosition2, 100);
                glVertex2f(mostLeftBuildingWindowXPosition2 - 5, 100);
                glVertex2f(mostLeftBuildingWindowXPosition2 - 5, -200);
                glVertex2f(mostLeftBuildingWindowXPosition2, -200);
                glEnd();
            }
            mostLeftBuildingWindowXPosition2 += 75;
        }





        glBegin(GL_QUADS); //Roof
        glColor3ub(BuildingWhiteColorRed4 - 50, BuildingWhiteColorGreen4 - 50, BuildingWhiteColorBlue4 - 50);
        glVertex2f(-430, 125);
        glVertex2f(-750, 75);
        glVertex2f(-750, 50);
        glVertex2f(-430, 100);
        glEnd();

        glBegin(GL_QUADS); //Roof
        glColor3ub(BuildingWhiteColorRed4 - 50, BuildingWhiteColorGreen4 - 50, BuildingWhiteColorBlue4 - 50);
        glVertex2f(-750, 75);
        glVertex2f(-960, 100);
        glVertex2f(-960, 75);
        glVertex2f(-750, 50);

        glEnd();


        // Building Most Left ->End


        //Final Building

        glBegin(GL_QUADS);

        glColor3ub(22,109,122);
        glVertex2f(370, 50);
        glVertex2f(-180, 50);
        glVertex2f(-180, -200);
        glVertex2f(370, -200);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(22,109,122);
       glVertex2f(160, 50);   // Top-right corner
    glVertex2f(15, 50);    // Top-left corner
    glVertex2f(15, 140);   // Upper-left corner of the square
    glVertex2f(160, 140);  // Upper-right corner of the square
    glVertex2f(160, -150); // Bottom-right corner
    glVertex2f(15, -150);  // Bottom-left corner
        glEnd();





        int mainBuildingWindowXposition = -130;

        for (int i = 0;i < 10;i++) {
            if (mainBuildingWindowXposition < 360) {
                glBegin(GL_QUADS);
                glColor3ub(mainBuildingWindowColorRed, mainBuildingWindowColorGreen, mainBuildingWindowColorBlue);
                glVertex2f(mainBuildingWindowXposition, 30);
                glVertex2f(mainBuildingWindowXposition - 30, 30);
                glVertex2f(mainBuildingWindowXposition - 30, 0);
                glVertex2f(mainBuildingWindowXposition, 0);
                glEnd();
            }
            mainBuildingWindowXposition += 60;
        }


        mainBuildingWindowXposition = -130;

        for (int i = 0;i < 10;i++) {
            if (mainBuildingWindowXposition < 360) {
                glBegin(GL_QUADS);
                glColor3ub(mainBuildingWindowColorRed, mainBuildingWindowColorGreen, mainBuildingWindowColorBlue);
                glVertex2f(mainBuildingWindowXposition, -30);
                glVertex2f(mainBuildingWindowXposition - 30, -30);
                glVertex2f(mainBuildingWindowXposition - 30, -60);
                glVertex2f(mainBuildingWindowXposition, -60);
                glEnd();
            }
            mainBuildingWindowXposition += 60;
        }

        mainBuildingWindowXposition = -130;

        for (int i = 0;i < 3;i++) {
            if (mainBuildingWindowXposition < 360) {
                glBegin(GL_QUADS);
                glColor3ub(mainBuildingWindowColorRed, mainBuildingWindowColorGreen, mainBuildingWindowColorBlue);
                glVertex2f(mainBuildingWindowXposition, -90);
                glVertex2f(mainBuildingWindowXposition - 30, -90);
                glVertex2f(mainBuildingWindowXposition - 30, -120);
                glVertex2f(mainBuildingWindowXposition, -120);
                glEnd();
            }
            mainBuildingWindowXposition += 60;
        }


        mainBuildingWindowXposition = 230;

        for (int i = 0;i < 3;i++) {
            if (mainBuildingWindowXposition < 360) {
                glBegin(GL_QUADS);
                glColor3ub(mainBuildingWindowColorRed, mainBuildingWindowColorGreen, mainBuildingWindowColorBlue);
                glVertex2f(mainBuildingWindowXposition, -90);
                glVertex2f(mainBuildingWindowXposition - 30, -90);
                glVertex2f(mainBuildingWindowXposition - 30, -120);
                glVertex2f(mainBuildingWindowXposition, -120);
                glEnd();
            }
            mainBuildingWindowXposition += 60;
        }


        glBegin(GL_QUADS);
        glColor3ub(mainBuildingWindowColorRed, mainBuildingWindowColorGreen, mainBuildingWindowColorBlue);
        glVertex2f(150, -85);
        glVertex2f(45, -85);
        glVertex2f(45, -200);
        glVertex2f(150, -200);
        glEnd();

        glBegin(GL_QUADS);
        glColor3ub(BuildingWhiteColorRed5, BuildingWhiteColorGreen5, BuildingWhiteColorBlue5);
        glVertex2f(390, -180);
        glVertex2f(-200, -180);
        glVertex2f(-200, -220);
        glVertex2f(390, -220);
        glEnd();
        //Final Building -> End


// Tree Trunk
glBegin(GL_QUADS);
glColor3ub(139, 69, 19); // Brown color for the trunk
glVertex2f(850, -200);
glVertex2f(880, -200);
glVertex2f(880, -100);
glVertex2f(850, -100);
glEnd();

// Bottom Triangle (Largest) - moved downward
glBegin(GL_TRIANGLES);
glColor3ub(34, 139, 34); // Green color for leaves
glVertex2f(820, -120);
glVertex2f(865, -20);
glVertex2f(910, -120);
glEnd();

// Middle Triangle
glBegin(GL_TRIANGLES);
glColor3ub(34, 160, 34);
glVertex2f(830, -70);
glVertex2f(865, 30);
glVertex2f(900, -70);
glEnd();

// Top Triangle (Smallest)
glBegin(GL_TRIANGLES);
glColor3ub(34, 180, 34);
glVertex2f(840, -20);
glVertex2f(865, 80);
glVertex2f(890, -20);
glEnd();

// ================= CENTER TREE (Larger Size) =================

// Tree Trunk (Slightly Wider & Taller)
glBegin(GL_QUADS);
glColor3ub(139, 69, 19); // Brown color for the trunk
glVertex2f(740, -200);
glVertex2f(790, -200);
glVertex2f(790, -90);
glVertex2f(740, -90);
glEnd();

// Bottom Triangle (Largest) - moved downward & scaled up
glBegin(GL_TRIANGLES);
glColor3ub(34, 139, 34); // Green color for leaves
glVertex2f(700, -140);
glVertex2f(765, -30);
glVertex2f(830, -140);
glEnd();

// Middle Triangle (Slightly Larger)
glBegin(GL_TRIANGLES);
glColor3ub(34, 160, 34);
glVertex2f(715, -80);
glVertex2f(765, 50);
glVertex2f(815, -80);
glEnd();

// Top Triangle (Larger than others)
glBegin(GL_TRIANGLES);
glColor3ub(34, 180, 34);
glVertex2f(730, 0);
glVertex2f(765, 120);
glVertex2f(800, 0);
glEnd();

// ================= LEFT TREE =================

// Tree Trunk
glBegin(GL_QUADS);
glColor3ub(139, 69, 19); // Brown color for the trunk
glVertex2f(650, -200);
glVertex2f(680, -200);
glVertex2f(680, -100);
glVertex2f(650, -100);
glEnd();

// Bottom Triangle (Largest) - moved downward
glBegin(GL_TRIANGLES);
glColor3ub(34, 139, 34); // Green color for leaves
glVertex2f(620, -120);
glVertex2f(665, -20);
glVertex2f(710, -120);
glEnd();

// Middle Triangle
glBegin(GL_TRIANGLES);
glColor3ub(34, 160, 34);
glVertex2f(630, -70);
glVertex2f(665, 30);
glVertex2f(700, -70);
glEnd();

// Top Triangle (Smallest)
glBegin(GL_TRIANGLES);
glColor3ub(34, 180, 34);
glVertex2f(640, -20);
glVertex2f(665, 80);
glVertex2f(690, -20);
glEnd();










        //LampPost

        int lampPostXPosition = -670;

        for (int i = 0;i < 4;i++) {

                 // Move the second lamp post to the right (i == 1)
    if (i == 1) {
        lampPostXPosition += 44;  // Move the second lamp post 30 units to the right
    }
            if (lampPostXPosition < 700) {
                glBegin(GL_QUADS);
                glColor3ub(75, 75, 75);
                glVertex2f(lampPostXPosition, -170);
                glVertex2f(lampPostXPosition - 7.5, -170);
                glVertex2f(lampPostXPosition - 15, -170);
                glVertex2f(lampPostXPosition + 7.5, -170);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(75, 75, 75);
                glVertex2f(lampPostXPosition - 1.5, -100);
                glVertex2f(lampPostXPosition - 6, -100);
                glVertex2f(lampPostXPosition - 6, -200);
                glVertex2f(lampPostXPosition - 1.5, -200);
                glEnd();


                glBegin(GL_QUADS);
                glColor3ub(lampPostLightColorRed, lampPostLightColorGreen, lampPostLightColorBlue);
                glVertex2f(lampPostXPosition + 8.5, -100);
                glVertex2f(lampPostXPosition - 16, -100);
                glVertex2f(lampPostXPosition - 13, -130);
                glVertex2f(lampPostXPosition + 5.5, -130);
                glEnd();

                glBegin(GL_QUADS);
                glColor3ub(75, 75, 75);
                glVertex2f(lampPostXPosition + 2.5, -200);
                glVertex2f(lampPostXPosition - 10, -200);
                glVertex2f(lampPostXPosition - 13, -230);
                glVertex2f(lampPostXPosition + 5.5, -230);
                glEnd();
            }
            lampPostXPosition += 650;



        }

int sideWalkBenchXPosition = -320; // TrainStationBench

for (int i = 0; i < 3; i++) {
    if (sideWalkBenchXPosition < 960) {
        // Bench Seat Left
        glBegin(GL_QUADS);
        glColor3ub(62, 72, 123);
        glVertex2f(sideWalkBenchXPosition, -180); // Lowered (was -170)
        glVertex2f(sideWalkBenchXPosition - 30, -180); // Lowered (was -170)
        glVertex2f(sideWalkBenchXPosition - 30, -210); // Lowered (was -200)
        glVertex2f(sideWalkBenchXPosition, -210); // Lowered (was -200)
        glEnd();

        // Bench Seat Middle Left
        glBegin(GL_QUADS);
        glColor3ub(62, 72, 123);
        glVertex2f(sideWalkBenchXPosition - 35, -180); // Lowered (was -170)
        glVertex2f(sideWalkBenchXPosition - 65, -180); // Lowered (was -170)
        glVertex2f(sideWalkBenchXPosition - 65, -210); // Lowered (was -200)
        glVertex2f(sideWalkBenchXPosition - 35, -210); // Lowered (was -200)
        glEnd();

        // Bench Seat Middle Right
        glBegin(GL_QUADS);
        glColor3ub(62, 72, 123);
        glVertex2f(sideWalkBenchXPosition - 70, -180); // Lowered (was -170)
        glVertex2f(sideWalkBenchXPosition - 100, -180); // Lowered (was -170)
        glVertex2f(sideWalkBenchXPosition - 100, -210); // Lowered (was -200)
        glVertex2f(sideWalkBenchXPosition - 70, -210); // Lowered (was -200)
        glEnd();

        // Bench Back Left
        glBegin(GL_QUADS);
        glColor3ub(23, 24, 90);
        glVertex2f(sideWalkBenchXPosition + 2, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 32, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 32, -204); // Lowered (was -194)
        glVertex2f(sideWalkBenchXPosition + 2, -204); // Lowered (was -194)
        glEnd();

        // Bench Back Middle Left
        glBegin(GL_QUADS);
        glColor3ub(23, 24, 90);
        glVertex2f(sideWalkBenchXPosition - 33, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 67, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 67, -204); // Lowered (was -194)
        glVertex2f(sideWalkBenchXPosition - 33, -204); // Lowered (was -194)
        glEnd();

        // Bench Back Middle Right
        glBegin(GL_QUADS);
        glColor3ub(23, 24, 90);
        glVertex2f(sideWalkBenchXPosition - 68, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 102, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 102, -204); // Lowered (was -194)
        glVertex2f(sideWalkBenchXPosition - 68, -204); // Lowered (was -194)
        glEnd();

        // Bench Seat
        glBegin(GL_QUADS);
        glColor3ub(110, 110, 110);
        glVertex2f(sideWalkBenchXPosition + 5, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 105, -212); // Lowered (was -202)
        glVertex2f(sideWalkBenchXPosition - 105, -216); // Lowered (was -206)
        glVertex2f(sideWalkBenchXPosition + 5, -216); // Lowered (was -206)
        glEnd();

        // Bench Back Right
        glBegin(GL_QUADS);
        glColor3ub(110, 110, 110);
        glVertex2f(sideWalkBenchXPosition + 5, -213); // Lowered (was -205)
        glVertex2f(sideWalkBenchXPosition + 2, -213); // Lowered (was -205)
        glVertex2f(sideWalkBenchXPosition + 2, -228); // Lowered (was -220)
        glVertex2f(sideWalkBenchXPosition + 5, -228); // Lowered (was -220)
        glEnd();

        // Bench Back Left Right
        glBegin(GL_QUADS);
        glColor3ub(110, 110, 110);
        glVertex2f(sideWalkBenchXPosition - 102, -213); // Lowered (was -205)
        glVertex2f(sideWalkBenchXPosition - 105, -213); // Lowered (was -205)
        glVertex2f(sideWalkBenchXPosition - 105, -228); // Lowered (was -220)
        glVertex2f(sideWalkBenchXPosition - 102, -228); // Lowered (was -220)
        glEnd();
    }
    sideWalkBenchXPosition += 700;
}





        // Car1

        glBegin(GL_POLYGON);
        glColor3ub(car1YellowColorRed, car1YellowColorGreen, car1YellowColorBlue);
        glVertex2f(car1Xposition - 5, -300);  // Moved further up
        glVertex2f(car1Xposition - 145, -300); // Moved further up
        glVertex2f(car1Xposition - 150, -315); // Moved further up
        glVertex2f(car1Xposition - 150, -340); // Moved further up
        glVertex2f(car1Xposition - 145, -345); // Moved further up
        glVertex2f(car1Xposition - 5, -345);   // Moved further up
        glVertex2f(car1Xposition, -340);       // Moved further up
        glVertex2f(car1Xposition, -315);       // Moved further up
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(car1BlackColorRed, car1BlackColorGreen, car1BlackColorBlue);
        glVertex2f(car1Xposition - 10, -270); // Moved further up
        glVertex2f(car1Xposition - 92, -270); // Moved further up
        glVertex2f(car1Xposition - 100, -275); // Moved further up
        glVertex2f(car1Xposition - 125, -300); // Moved further up
        glVertex2f(car1Xposition - 5, -300);   // Moved further up
        glVertex2f(car1Xposition - 5, -275);   // Moved further up
        glEnd();

        drawCircle2(car1Xposition - 30, -345, 15); // Tyre (Moved further up)
        drawCircle2(car1Xposition - 120, -345, 15); // Tyre (Moved further up)

        drawCircle3(car1Xposition - 30, -345, 10); // Tyre Inner Circle (Moved further up)
        drawCircle3(car1Xposition - 120, -345, 10); // Tyre Inner Circle (Moved further up)


        // Car2

        glBegin(GL_POLYGON);
        glColor3ub(car2GreenColorRed, car2GreenColorGreen, car2GreenColorBlue);
        glVertex2f(car2Xposition - 5, -300);  // Moved further up
        glVertex2f(car2Xposition - 145, -300); // Moved further up
        glVertex2f(car2Xposition - 150, -305); // Moved further up
        glVertex2f(car2Xposition - 150, -340); // Moved further up
        glVertex2f(car2Xposition - 145, -345); // Moved further up
        glVertex2f(car2Xposition - 5, -345);   // Moved further up
        glVertex2f(car2Xposition, -340);       // Moved further up
        glVertex2f(car2Xposition, -315);       // Moved further up
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(car1BlackColorRed, car1BlackColorGreen, car1BlackColorBlue);
        glVertex2f(car2Xposition - 10, -270); // Moved further up
        glVertex2f(car2Xposition - 92, -270); // Moved further up
        glVertex2f(car2Xposition - 100, -275); // Moved further up
        glVertex2f(car2Xposition - 125, -300); // Moved further up
        glVertex2f(car2Xposition - 5, -300);   // Moved further up
        glVertex2f(car2Xposition - 5, -275);   // Moved further up
        glEnd();

        drawCircle2(car2Xposition - 30, -345, 15); // Tyre (Moved further up)
        drawCircle2(car2Xposition - 120, -345, 15); // Tyre (Moved further up)

        drawCircle3(car2Xposition - 30, -345, 10); // Tyre Inner Circle (Moved further up)
        drawCircle3(car2Xposition - 120, -345, 10); // Tyre Inner Circle (Moved further up)


// Car3
glBegin(GL_POLYGON);
glColor3ub(truck1RedcolorRed, truck1RedcolorGreen, truck1RedcolorBlue);
glVertex2f(car3Xposition - 5, -480);  // Moved up
glVertex2f(car3Xposition - 145, -480);  // Moved up
glVertex2f(car3Xposition - 150, -485);  // Moved up

glVertex2f(car3Xposition - 150, -510);  // Moved up
glVertex2f(car3Xposition - 145, -515);  // Moved up
glVertex2f(car3Xposition - 5, -515);  // Moved up
glVertex2f(car3Xposition, -510);  // Moved up
glVertex2f(car3Xposition, -485);  // Moved up

glEnd();

glBegin(GL_POLYGON);
glColor3ub(car1BlackColorRed, car1BlackColorGreen, car1BlackColorBlue);
glVertex2f(car3Xposition - 92, -450);  // Moved up
glVertex2f(car3Xposition - 140, -455);  // Moved up
glVertex2f(car3Xposition - 145, -480);  // Moved up
glVertex2f(car3Xposition - 25, -480);  // Moved up
glVertex2f(car3Xposition - 45, -455);  // Moved up
glEnd();

drawCircle2(car3Xposition - 30, -515, 15); // Tyre (Moved up)
drawCircle2(car3Xposition - 120, -515, 15);

drawCircle3(car3Xposition - 30, -515, 10); // Tyre Inner Circle (Moved up)
drawCircle3(car3Xposition - 120, -515, 10);

// Car4
glBegin(GL_POLYGON);
glColor3ub(car4WhiteColorRed, car4WhiteColorGreen, car4WhiteColorBlue);
glVertex2f(car4Xposition - 5, -480);  // Moved up
glVertex2f(car4Xposition - 145, -480);  // Moved up
glVertex2f(car4Xposition - 150, -485);  // Moved up

glVertex2f(car4Xposition - 150, -510);  // Moved up
glVertex2f(car4Xposition - 145, -515);  // Moved up
glVertex2f(car4Xposition - 5, -515);  // Moved up
glVertex2f(car4Xposition, -510);  // Moved up
glVertex2f(car4Xposition, -485);  // Moved up

glEnd();

glBegin(GL_POLYGON);
glColor3ub(car1BlackColorRed, car1BlackColorGreen, car1BlackColorBlue);
glVertex2f(car4Xposition - 92, -450);  // Moved up
glVertex2f(car4Xposition - 140, -455);  // Moved up
glVertex2f(car4Xposition - 145, -480);  // Moved up
glVertex2f(car4Xposition - 25, -480);  // Moved up
glVertex2f(car4Xposition - 45, -455);  // Moved up
glEnd();

drawCircle2(car4Xposition - 30, -515, 15); // Tyre (Moved up)
drawCircle2(car4Xposition - 120, -515, 15);

drawCircle3(car4Xposition - 30, -515, 10); // Tyre Inner Circle (Moved up)
drawCircle3(car4Xposition - 120, -515, 10);











 // Get the current time
    float currentTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0f; // Time in seconds

    // If enough time has passed, switch the light color
    if (currentTime - lastChangeTime > timerInterval) {
        lastChangeTime = currentTime;  // Update the last change time

        // Switch to the next light
        currentLight = (currentLight + 1) % 3;  // Cycle through 0 -> 1 -> 2 -> 0


        // Set the timer interval for the next light
        if (currentLight == 0) {
            timerInterval = redLightDuration;  // Red light duration
        } else if (currentLight == 1) {
            timerInterval = yellowLightDuration;  // Yellow light duration
        } else if (currentLight == 2) {
            timerInterval = greenLightDuration;  // Green light duration
        }
    }

    // Light case (box that holds the lights) - smaller
    glBegin(GL_POLYGON);
    glColor3ub(204, 122, 0);  // Orange box for light casing
    glVertex2f(-60.0f + 30.0f + 30.0f, -50.0f - 7.0f);  // Left top corner
    glVertex2f(-20.0f + 30.0f + 30.0f, -50.0f - 7.0f);  // Right top corner
    glVertex2f(-20.0f + 30.0f + 30.0f, -120.0f - 7.0f);  // Right bottom corner
    glVertex2f(-60.0f + 30.0f + 30.0f, -120.0f - 7.0f);  // Left bottom corner
    glEnd();

    glLineWidth(3.0f);
    glBegin(GL_LINES);
    glColor3ub(0, 0, 0);  // Black lines for box separation
    glVertex2f(-60.0f + 30.0f + 30.0f, -50.0f - 7.0f);
    glVertex2f(-20.0f + 30.0f + 30.0f, -50.0f - 7.0f);
    glVertex2f(-20.0f + 30.0f + 30.0f, -50.0f - 7.0f);
    glVertex2f(-20.0f + 30.0f + 30.0f, -120.0f - 7.0f);
    glVertex2f(-20.0f + 30.0f + 30.0f, -120.0f - 7.0f);
    glVertex2f(-60.0f + 30.0f + 30.0f, -120.0f - 7.0f);
    glVertex2f(-60.0f + 30.0f + 30.0f, -120.0f - 7.0f);
    glVertex2f(-60.0f + 30.0f + 30.0f, -50.0f - 7.0f);
    glEnd();

    glLineWidth(1.0f);
    glBegin(GL_LINES);
    // Vertical lines inside the box (to separate lights)
    glVertex2f(-60.0f + 30.0f + 30.0f, -75.0f - 7.0f);
    glVertex2f(-20.0f + 30.0f + 30.0f, -75.0f - 7.0f);

    glVertex2f(-60.0f + 30.0f + 30.0f, -95.0f - 7.0f);
    glVertex2f(-20.0f + 30.0f + 30.0f, -95.0f - 7.0f);
    glEnd();

    // Draw the individual lights
    float y = -65.0f - 7.0f;

    // Top Light - Red
    if (currentLight == 0) {
        glColor3ub(204, 0, 0);  // Red
    } else {
        glColor3ub(50, 50, 50);  // Grey (off)
    }
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y);
    for (int i = 0; i <= triangleAmount; i++) {
        glVertex2f(x + (radius * cos(i * twicePi / triangleAmount)),
                   y + (radius * sin(i * twicePi / triangleAmount)));
    }
    glEnd();

    // Middle Light - Yellow
    y = -85.0f - 7.0f;  // Slightly adjusted position
    if (currentLight == 1) {
        glColor3ub(255, 204, 0);  // Yellow
    } else {
        glColor3ub(50, 50, 50);  // Grey (off)
    }
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y);
    for (int i = 0; i <= triangleAmount; i++) {
        glVertex2f(x + (radius * cos(i * twicePi / triangleAmount)),
                   y + (radius * sin(i * twicePi / triangleAmount)));
    }
    glEnd();

    // Bottom Light - Green
    y = -105.0f - 7.0f;  // Slightly adjusted position
    if (currentLight == 2) {
        glColor3ub(0, 128, 0);  // Green
    } else {
        glColor3ub(50, 50, 50);  // Grey (off)
    }
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y);
    for (int i = 0; i <= triangleAmount; i++) {
        glVertex2f(x + (radius * cos(i * twicePi / triangleAmount)),
                   y + (radius * sin(i * twicePi / triangleAmount)));
    }
    glEnd();







        //Truck1

        glBegin(GL_POLYGON);
        glColor3ub(truck1RedcolorRed, truck1RedcolorGreen, truck1RedcolorBlue);
        glVertex2f(truckXPosition - 5, -475);
        glVertex2f(truckXPosition - 90, -475);
        glVertex2f(truckXPosition - 90, -510);
        glVertex2f(truckXPosition - 5, -510);
        glVertex2f(truckXPosition, -505);
        glVertex2f(truckXPosition, -480);
        glEnd();


        glBegin(GL_POLYGON);
        glColor3ub(car1BlackColorRed, car1BlackColorGreen, car1BlackColorBlue);
        glVertex2f(truckXPosition - 40, -450);
        glVertex2f(truckXPosition - 90, -450);
        glVertex2f(truckXPosition - 90, -475);
        glVertex2f(truckXPosition - 25, -475);
        glEnd();

        glBegin(GL_POLYGON);
        glColor3ub(truck1RedcolorRed, truck1RedcolorGreen, truck1RedcolorBlue);
        glVertex2f(truckXPosition - 92, -483);
        glVertex2f(truckXPosition - 180, -483);
        glVertex2f(truckXPosition - 180, -510);
        glVertex2f(truckXPosition - 92, -510);
        glEnd();

        drawCircle2(truckXPosition - 30, -510, 15); //Tyre
        drawCircle2(truckXPosition - 135, -510, 15);

        drawCircle3(truckXPosition - 30, -510, 10); //Tyre Inner Circle
        drawCircle3(truckXPosition - 135, -510, 10);


// Truck2

glBegin(GL_POLYGON);
glColor3ub(truck2BluecolorRed, truck2BluecolorGreen, truck2BluecolorBlue);
glVertex2f(truck2Xposition + 40, -290);  // Moved up even further
glVertex2f(truck2Xposition - 50, -290);  // Moved up even further
glVertex2f(truck2Xposition - 50, -325);  // Moved up even further
glVertex2f(truck2Xposition - 45, -330);  // Moved up even further
glVertex2f(truck2Xposition + 40, -330);  // Moved up even further
glEnd();


glBegin(GL_POLYGON);
glColor3ub(car1BlackColorRed, car1BlackColorGreen, car1BlackColorBlue);
glVertex2f(truck2Xposition + 35, -250);  // Moved up slightly
glVertex2f(truck2Xposition - 30, -250);  // Moved up slightly
glVertex2f(truck2Xposition - 50, -290);  // Moved up slightly
glVertex2f(truck2Xposition + 40, -290);  // Moved up slightly
glVertex2f(truck2Xposition + 40, -255);  // Moved up slightly
glEnd();


glBegin(GL_POLYGON);
glColor3ub(truck2BluecolorRed, truck2BluecolorGreen, truck2BluecolorBlue);
glVertex2f(truck2Xposition + 195, -220);  // Moved up further
glVertex2f(truck2Xposition + 47, -220);   // Moved up further
glVertex2f(truck2Xposition + 42, -225);   // Moved up further
glVertex2f(truck2Xposition + 42, -330);   // Moved up further
glVertex2f(truck2Xposition + 200, -330);  // Moved up further
glVertex2f(truck2Xposition + 200, -225);  // Moved up further
glEnd();

glBegin(GL_POLYGON);
glColor3ub(50, 50, 50);
glVertex2f(truck2Xposition + 200, -320);  // Moved up further
glVertex2f(truck2Xposition - 50, -320);   // Moved up further
glVertex2f(truck2Xposition - 50, -325);   // Moved up further
glVertex2f(truck2Xposition - 45, -330);   // Moved up further
glVertex2f(truck2Xposition + 200, -330);  // Moved up further
glEnd();

drawCircle2(truck2Xposition + 160, -330, 20); // Tyre (Moved up further)
drawCircle2(truck2Xposition - 10, -330, 20);  // Tyre (Moved up further)

drawCircle3(truck2Xposition + 160, -330, 13); // Tyre Inner Circle (Moved up further)
drawCircle3(truck2Xposition - 10, -330, 13);  // Tyre Inner Circle (Moved up further)


    }
    glFlush();
    glutSwapBuffers();

    }




void reshape(int w, int h) {
    glViewport(0, 0, (GLsizei)w, (GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-960, 960, -540, 540);
    glMatrixMode(GL_MODELVIEW);
}

void handleMouse(int button, int state, int o, int p) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        environmentState = (environmentState == 0) ? 1 : 0; // Toggle day/night
        glutPostRedisplay(); // Refresh display
    }
}




void handleKeyPress(unsigned char key, int x, int y) {
    if (key == ' ') {
        trainSpeed = 0;

    } else if (key ==0){
        trainSpeed = 7;
    }
      else if (key =='a'){
        trainSpeed = 0;
    }
      else if (key =='d'){
        trainSpeed = 7;
    }


    else if (key == 'y' || key == 'Y') {
        trafficSoundState = 1;
        sndPlaySound("trainStop.wav", SND_ASYNC);
        glutPostRedisplay();
    }
    else if (key == '1')
    {
        sceneNo = 1;
        PlaySound(NULL, NULL, 0);
        PlaySound(TEXT("D:\\7th Sem\\Computer Graphics\\CG Codes\\CG Final Project 2025\\Metro.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
        glutPostRedisplay();


        glutPostRedisplay();

    }
        else if (key == '2')
        {
            sceneNo = 2;
            PlaySound(NULL, NULL, 0);
            PlaySound(TEXT("D:\\7th Sem\\Computer Graphics\\CG Codes\\CG Final Project 2025\\ocean.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
            glutPostRedisplay();
        }


else if (key == '3') {
    sceneNo = 3;

    if (currentLight == 1 || currentLight == 2)
    {  // Orange or Green light
        PlaySound(TEXT("D:\\7th Sem\\Computer Graphics\\CG Codes\\CG Final Project 2025\\traffic.wav"), NULL, SND_FILENAME | SND_ASYNC | SND_LOOP);
        //std::cout << "Traffic sound ON (Green or Orange Light)" << std::endl;  // Debug message
    }
    else {  // Red light
        PlaySound(NULL, NULL, 0);  // Stop the sound properly
        //std::cout << "Traffic sound OFF (Red Light)" << std::endl;  // Debug message
    }

    glutPostRedisplay();
}


    switch (key) {
    case 'f':
        speed1 = 0.0f;
        break;
    case 'g':
        speed1 = 10.0f;
        break;
    case 'h':
        speed2 = 0.0f;
        break;
    case 'j':
        speed2 = 10.0f;
        break;
    case 'k':
        speed3 = 0.0f;
        break;
    case 'l':
        speed3 = 10.0f;
        break;
    }
    glutPostRedisplay();
}
void mouseClickHandler(int button, int state1, int o, int p) { // Renamed
    if (button == GLUT_LEFT_BUTTON && state1 == GLUT_DOWN) {
        environmentState = (environmentState == 0) ? 1 : 0; // Toggle day/night
        glutPostRedisplay(); // Refresh display
    }
}
void drawCircle(float cx, float cy, float radius)
{
    int numSegments = 100;
    float theta = 2.0f * 3.1415926f / float(numSegments);
    float cosTheta = cos(theta);
    float sinTheta = sin(theta);

    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(255, 255, 255);
    for (int i = 0; i < numSegments; i++)
    {
        float x = radius * cos(i * theta);
        float y = radius * sin(i * theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}


void drawCircle2(float cx, float cy, float radius)
{
    int numSegments = 100;
    float theta = 2.0f * 3.1415926f / float(numSegments);
    float cosTheta = cos(theta);
    float sinTheta = sin(theta);

    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(55, 55, 55);
    for (int i = 0; i < numSegments; i++)
    {
        float x = radius * cos(i * theta);
        float y = radius * sin(i * theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}


void drawCircle3(float cx, float cy, float radius)
{
    int numSegments = 100;
    float theta = 2.0f * 3.1415926f / float(numSegments);
    float cosTheta = cos(theta);
    float sinTheta = sin(theta);

    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(221, 221, 221);
    for (int i = 0; i < numSegments; i++)
    {
        float x = radius * cos(i * theta);
        float y = radius * sin(i * theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}


void drawCircle4(float cx, float cy, float radius)
{
    int numSegments = 100;
    float theta = 2.0f * 3.1415926f / float(numSegments);
    float cosTheta = cos(theta);
    float sinTheta = sin(theta);

    glBegin(GL_TRIANGLE_FAN);
    glColor3ub(cloudColorRed, cloudColorGreen, cloudColorBlue);
    for (int i = 0; i < numSegments; i++)
    {
        float x = radius * cos(i * theta);
        float y = radius * sin(i * theta);
        glVertex2f(x + cx, y + cy);
    }
    glEnd();
}





void trainTimer(int) {
 trainXposition += trainSpeed;

    if (trainXposition > 2500) {
        trainXposition = -2450;
    }



    glutPostRedisplay();
    glutTimerFunc(20, trainTimer, 0);



    if (cloud4Position > -5000) {
        cloud4Position -= cloudSpeed;
        if (cloud4Position < -1000) {
            cloud4Position = 1200;
        }

        cloud1Position -= cloudSpeed;
        if (cloud1Position < -1000) {
            cloud1Position = 1200;
        }
        cloud2Position -= cloudSpeed;
        if (cloud2Position < -1000) {
            cloud2Position = 1200;
        }
        cloud3Position -= cloudSpeed;
        if (cloud3Position < -1000) {
            cloud3Position = 1200;
        }
        cloud5Position -= cloudSpeed;
        if (cloud5Position < -1000) {
            cloud5Position = 1200;
        }
        cloud6Position -= cloudSpeed;
        if (cloud6Position < -1000) {
            cloud6Position = 1200;
        }
    }



    boatXPosition += boatXSpeed;
    if (boatXPosition < -2000) {
        boatXPosition = 1200;
    }


 if (cloud4Position > -5000) {
        cloud4Position -= cloudSpeed;
        if (cloud4Position < -1000) {
            cloud4Position = 1200;
        }

        cloud1Position -= cloudSpeed;
        if (cloud1Position < -1000) {
            cloud1Position = 1200;
        }
        cloud2Position -= cloudSpeed;
        if (cloud2Position < -1000) {
            cloud2Position = 1200;
        }
        cloud3Position -= cloudSpeed;
        if (cloud3Position < -1000) {
            cloud3Position = 1200;
        }
        cloud5Position -= cloudSpeed;
        if (cloud5Position < -1000) {
            cloud5Position = 1200;
        }
        cloud6Position -= cloudSpeed;
        if (cloud6Position < -1000) {
            cloud6Position = 1200;
        }
    }



// Move vehicles if it's not red light (currentLight != 0)
if (currentLight != 0) {  // If it's not red light
    car1Xposition -= carSpeed;
    if (car1Xposition < -2000) {
        car1Xposition = 1200;
    }

    car2Xposition -= carSpeed;
    if (car2Xposition < -2000) {
        car2Xposition = 1200;
    }

    car3Xposition += carSpeed;
    if (car3Xposition > 2000) {
        car3Xposition = -1200;
    }

    car4Xposition += carSpeed;
    if (car4Xposition > 2000) {
        car4Xposition = -1200;
    }

    truckXPosition += carSpeed;
    if (truckXPosition > 2000) {
        truckXPosition = -1200;
    }

    truck2Xposition -= carSpeed;
    if (truck2Xposition < -2000) {
        truck2Xposition = 1200;
    }
}

// If the light is red (0), stop all vehicles
if (currentLight == 0) {
    // Vehicles stop moving
    car1Xposition = car1Xposition;  // No movement
    car2Xposition = car2Xposition;
    car3Xposition = car3Xposition;
    car4Xposition = car4Xposition;
    truckXPosition = truckXPosition;
    truck2Xposition = truck2Xposition;
}









    switch (state) {



    case 0:
        trainXposition = trainXposition;
        break;

    case 1:

        if (trainXposition > -3000) {
            trainXposition -= trainSpeed;
        }
        else {

            state = 0;
        }
        break;

    case -1:
        if (trainXposition < 1500) {
            trainXposition += trainSpeed;
        }
        else {
            state = 0;
        }

        break;

    }

}

